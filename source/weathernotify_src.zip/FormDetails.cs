/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for FormDetails.
	/// </summary>
	public class FormDetails : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
        private System.Windows.Forms.TextBox textBox_details;
        private ClassDetailsLanguage obj_details_language=null;
        private ClassOptions obj_options=null;
        private ClassMetar obj_metar=null;

		public FormDetails()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

            obj_details_language=new ClassDetailsLanguage();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

        private bool b_closed_forced=false;
        public void CloseForced()
        {
            this.b_closed_forced=true;
            this.Close();
        }
        private void FormDetails_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (this.b_closed_forced)
                return;
            e.Cancel=true;
            this.Hide();        
        }

        private string get_length(ClassOptions.LENGTH_UNITS unit,ClassLength obj_length)
        {
            switch (unit)
            {
                case ClassOptions.LENGTH_UNITS.FEET:
                    return obj_length.Ft.ToString("0")+this.obj_details_language.feet;
                case ClassOptions.LENGTH_UNITS.KM:
                    return obj_length.Km.ToString("0.0")+this.obj_details_language.kilometers;
                case ClassOptions.LENGTH_UNITS.METER:
                    return obj_length.Meter.ToString("0")+this.obj_details_language.meters;
                case ClassOptions.LENGTH_UNITS.MILES:
                    return obj_length.Miles.ToString("0.0")+this.obj_details_language.miles;
            }
            // error
            return "";
        }

        private string get_height(ClassOptions.HEIGTH_UNITS unit,ClassHeight obj_height)
        {
            switch (unit)
            {
                case ClassOptions.HEIGTH_UNITS.INCH:
                    return obj_height.Inch.ToString("0")+this.obj_details_language.inches;
                case ClassOptions.HEIGTH_UNITS.MM:
                    return obj_height.Mm.ToString("0")+this.obj_details_language.millimeters;
            }
            // error
            return "";
        }

        private string get_speed(ClassOptions.WIND_UNITS unit,ClassWindSpeed obj_speed)
        {
            switch (unit)
            {
                case ClassOptions.WIND_UNITS.BEAUFORT:
                    return obj_speed.Beaufort.ToString("0")+this.obj_details_language.beaufort;
                case ClassOptions.WIND_UNITS.KMH:
                    return obj_speed.Kmh.ToString("0.0")+this.obj_details_language.kilometers_per_hour;
                case ClassOptions.WIND_UNITS.KNOTS:
                    return obj_speed.Knots.ToString("0.0")+this.obj_details_language.knots;
                case ClassOptions.WIND_UNITS.MH:
                    return obj_speed.Mileshours.ToString("0.0")+this.obj_details_language.miles_per_hour;
                case ClassOptions.WIND_UNITS.MS:
                    return obj_speed.Ms.ToString("0.0")+this.obj_details_language.meters_per_second;
            }
            return "";
        }

        private string get_pressure(ClassOptions.PRESSURE_UNITS unit,ClassPressure obj_pressure)
        {
            switch (unit)
            {
                case ClassOptions.PRESSURE_UNITS.ATM:
                    return obj_pressure.Atm.ToString("0")+this.obj_details_language.Atm;
                case ClassOptions.PRESSURE_UNITS.HPA:
                    return obj_pressure.Hpa.ToString("0")+this.obj_details_language.hPa;
                case ClassOptions.PRESSURE_UNITS.INHG:
                    return obj_pressure.Inhg.ToString("0.00")+this.obj_details_language.inHg;
                case ClassOptions.PRESSURE_UNITS.MMHG:
                    return obj_pressure.Mmhg.ToString("0")+this.obj_details_language.mmHg;
            }
            return "";
        }

        private string get_weather_descriptor_description(string descriptor)
        {
            return Class_StrHash.find_hash_table(descriptor,this.obj_details_language.weather);
        }
        private string get_wind_dir_short_long(string descriptor)
        {
            return Class_StrHash.find_hash_table(descriptor,this.obj_details_language.wind_dir_short_long);
        }

        private string get_runway_tendency_description(string descriptor)
        {
            switch (descriptor)
            {
                case "":
                    return "";
                case "U":
                    return this.obj_details_language.runway_upward_tendency;
                case "D":
                    return this.obj_details_language.runway_downward_tendency;
                case "N":
                    return this.obj_details_language.runway_no_tendency;
            }
            // error
            return "";
        }

        public void set_metar(ClassMetar obj_metar,ClassOptions obj_options)
        {
            this.obj_metar=obj_metar;
            this.obj_options=obj_options;

            string str="";

            if (this.obj_metar==null)
            {
                this.textBox_details.Text=String.Format(this.obj_details_language.no_data,this.obj_options.city.name+" ("+this.obj_options.city.country+")");
                this.textBox_details.SelectionLength=0;
                this.textBox_details.SelectionStart=this.textBox_details.Text.Length;
                return;
            }

            str+=this.print_pretty_location();
            str+=this.print_pretty_time();
            str+=this.print_pretty_wind();
            str+=this.print_pretty_temperature();
            if (this.obj_metar.temperature.heatindex.is_set())
                str+=this.print_pretty_feelslike(this.obj_metar.temperature.heatindex);
            else if (this.obj_metar.temperature.windchill.is_set())
                str+=this.print_pretty_feelslike(this.obj_metar.temperature.windchill);
            str+=this.print_pretty_altimeter();
            str+=this.print_pretty_rel_humidity();
            str+=this.print_pretty_clouds();
            str+=this.print_pretty_visibility();
            str+=this.print_pretty_precipitation();
            str+=this.print_pretty_temp_min_max();
            str+=this.print_pretty_runway();
            str+=this.print_pretty_weather();

            this.textBox_details.Text=str;
            this.textBox_details.SelectionLength=0;
            this.textBox_details.SelectionStart=this.textBox_details.Text.Length;
        }

        private string print_pretty_location()
        {
            return String.Format(this.obj_details_language.location,this.obj_options.city.name);
        }

        #region print_pretty_time 
        private string print_pretty_time()
        {
            string str_min="";
            string str_time_ago="";
            if (DateTime.UtcNow<this.obj_metar.report_time)
            {
                if (DateTime.UtcNow.Date==this.obj_metar.report_time.Date)
                    str_time_ago=this.obj_details_language.time_a_moment;
            }
            else
            {
                TimeSpan dt=DateTime.UtcNow-this.obj_metar.report_time;
                if (dt.Days>0)// report is one or more day ago
                {
                    dt=DateTime.UtcNow-this.obj_metar.report_time;
                    if (dt.Days<=1)
                        str_time_ago=this.obj_details_language.time_one_day;
                    else
                        str_time_ago=String.Format(this.obj_details_language.time_several_days,dt.Days);
                }
                else if (dt.Hours>0)
                {
                    if (dt.Minutes>=1)
                        str_min=String.Format(this.obj_details_language.time_minutes,dt.Minutes);
                    if (dt.Hours==1)
                        str_time_ago=String.Format(this.obj_details_language.time_one_hour,dt.Minutes);
                    else
                        str_time_ago=String.Format(this.obj_details_language.time_several_hours,dt.Hours,dt.Minutes);
                }
                else
                {
                    if (dt.Minutes<5)
                        str_time_ago=this.obj_details_language.time_a_moment;
                    else
                        str_time_ago=dt.Minutes.ToString()+this.obj_details_language.minutes;
                }
            }
            return String.Format(this.obj_details_language.time_format,str_time_ago,this.obj_metar.report_time);
        }
        #endregion

        #region print_pretty_wind
        private string print_pretty_wind()
        {
            string str="";
            if (!this.obj_metar.wind.b_no_data)
            {
                if (this.obj_metar.wind.speed.Ms!=0)
                    str+=this.obj_details_language.wind_blowing+this.get_speed(this.obj_options.wind_unit,this.obj_metar.wind.speed);
                if (this.obj_metar.wind.gust_speed.Ms!=0)
                    str+=this.obj_details_language.wind_with_gusts+this.get_speed(this.obj_options.wind_unit,this.obj_metar.wind.speed);
                if (this.obj_metar.wind.direction.deg==ClassWindDir.VRB)
                {
                    str+=this.obj_details_language.wind_variable;
                }
                else
                {
                    str+=this.obj_details_language.wind_from
                        +this.obj_details_language.wind_dir[(int)Math.Round(this.obj_metar.wind.direction.deg/22.5,0)]
                        +" ("+this.obj_metar.wind.direction.deg.ToString("0")+"�)";
                    if (this.obj_metar.wind.direction.var_beg!=0)
                    {
                        str+=String.Format(this.obj_details_language.wind_varying,
                            this.obj_details_language.wind_dir[(int)Math.Round(this.obj_metar.wind.direction.var_beg/22.5,0)],
                            this.obj_metar.wind.direction.var_beg.ToString("0"),
                            this.obj_details_language.wind_dir[(int)Math.Round(this.obj_metar.wind.direction.var_end/22.5,0)],
                            this.obj_metar.wind.direction.var_end.ToString("0"));
                    }
                    else
                    {
                        str+="."+this.obj_details_language.wind_calm;
                    }
                }
            }
            if (str!="")
                str+=".";
            return str;
        }
        #endregion

        #region print_pretty_temperature
        private string print_pretty_temperature()
        {
            string str="";
            str+=this.obj_details_language.temperature+this.obj_metar.temperature.current.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit);

            if (this.obj_metar.temperature.dew.is_set())
            {
                str+=this.obj_details_language.dew_point
                    +this.obj_metar.temperature.dew.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit);
            }
            if (str!="")
                str+=".";
            return str;
        }
        #endregion

        #region print_pretty_feelslike
        private string print_pretty_feelslike(ClassTemperature ct)
        {
            return this.obj_details_language.feelslike+ct.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit)+".";
        }
        #endregion

        #region print_pretty_altimeter
        private string print_pretty_altimeter()
        {
            string str="";
            if (!this.obj_metar.pressure.b_no_data)
                str+=this.obj_details_language.altimeter
                    +this.get_pressure(this.obj_options.pressure_unit,this.obj_metar.pressure)
                    +".";
            return str;
        }
        #endregion

        #region print_pretty_rel_humidity
        private string print_pretty_rel_humidity()
        {
            if (this.obj_details_language.rel_humidity=="")
                return "";
            return this.obj_details_language.rel_humidity
                   +this.obj_metar.humidity.relative.ToString("0.0")
                   +"%.";
        }
        #endregion

        #region parse_cloud_group
        private string parse_cloud_group(ClassClouds obj_clouds)
        {
            if (obj_clouds==null)
                return "";
            if (obj_clouds.b_no_data)
                return "";
            string str="";

            string cumulus="";
            if (obj_clouds.prefix==-1)
                str+=this.obj_details_language.visibility_less_than;
            switch (obj_clouds.coverage)
            {
                case ClassClouds.COVERAGE.OVC:
                    str+=this.obj_details_language.cloud_overcast
                        +" "+this.get_length(this.obj_options.height_unit,obj_clouds.length);
                    break;
                case ClassClouds.COVERAGE.VV:
                    str+=this.obj_details_language.cloud_vertical_visibility
                        +" "+this.get_length(this.obj_options.height_unit,obj_clouds.length);
                    break;
                case ClassClouds.COVERAGE.CAVOK:
                    ClassLength clen=new ClassLength();
                    clen.Meter=1500;
                    str+=String.Format(this.obj_details_language.cavok,this.get_length(this.obj_options.height_unit,clen));
                    break;
                default:
                    if (obj_clouds.cumulus!="")
                    {
                        switch (obj_clouds.cumulus)
                        {
                            case "CB":
                                cumulus=this.obj_details_language.cumulonimbus;
                                break;
                            case "TCU":
                                cumulus=this.obj_details_language.towering_cumulus;
                                break;
                            default:
                                cumulus="";
                                // unknown
                                break;
                        }
                    }
                    /* Here comes the output. We start with the description of the
                        * clouds ('few', 'broken' etc) and then append $cumulus, which
                        * might be an empty string. Then comes the height of the
                        * cloud-layer.
                        */
                    // we are not in CAVOK and VV condition because of switch --> we can use enum as index
                    str+=this.obj_details_language.cloud_condition[(int)obj_clouds.coverage]
                        +cumulus
                        +this.obj_details_language.cloud_height
                        +this.get_length(this.obj_options.height_unit,obj_clouds.length);
                    break;
            }
            return str;
        }
        #endregion

        #region print_pretty_clouds
        private string print_pretty_clouds()
        {
            if (this.obj_metar.clouds_group_number==0)
                return "";
            if (this.obj_metar.clouds_array[0].b_no_data
                ||(this.obj_metar.clouds_array[0].coverage==ClassClouds.COVERAGE.CLR)
                ||(this.obj_metar.clouds_array[0].coverage==ClassClouds.COVERAGE.SKC))
            {
                return this.obj_details_language.cloud_clear;
            }
            // else : We have up to three cloud groups
            string[] cloud_str=new string[this.obj_metar.clouds_group_number];
            string ovc="";
            for (int cnt=0;cnt<this.obj_metar.clouds_group_number;cnt++)// we know the number of clouds group
            {
                cloud_str[cnt]="";
                if (this.obj_metar.clouds_array[cnt].coverage==ClassClouds.COVERAGE.OVC)
                {
                    if (cnt==0)
                        return this.parse_cloud_group(this.obj_metar.clouds_array[cnt]);
                    else
                        ovc=this.parse_cloud_group(this.obj_metar.clouds_array[cnt]);
                }
                else
                    cloud_str[cnt]=this.parse_cloud_group(this.obj_metar.clouds_array[cnt]);
            }
            string str=this.list_sentences(cloud_str);
            if (str!="")
                str=this.obj_details_language.cloud_group_beg+str+this.obj_details_language.cloud_group_end;
            str+=ovc;
            return str;
        }
        #endregion

        #region list_sentences
        /// <summary>
        ///   Builds sentences from smaller bits.
        ///   
        ///   Takes an arbitrary number of strings as its arguments, and
        ///   returns them with commas between.
        ///   
        ///   Only non-empty arguments are used, so it's safe to call this
        ///   function with empty strings. But if you try to call it with
        /// </summary>
        /// <param name="sentences"></param>
        /// <returns>The arguments put together</returns>
        private string list_sentences (string[] sentences)
        {
        
            if (sentences == null)
                return "";
        
            string str="";
            int cnt=0;
            // remove empty sentences
            int nb_not_empty_sentences=0;
            string[] not_empty_sentences=new string[sentences.Length];
            for (cnt=0;cnt<sentences.Length;cnt++)
            {
                if (sentences[cnt]==null)
                    continue;
                if (sentences[cnt]=="")
                    continue;
                not_empty_sentences[nb_not_empty_sentences]=sentences[cnt];
                nb_not_empty_sentences++;
            }

            switch (nb_not_empty_sentences)
            {
                case 0:
                    return "";
                case 1:
                    return not_empty_sentences[0];
                case 2:
                    return not_empty_sentences[0]+this.obj_details_language.list_sentences_and+not_empty_sentences[1];
                default:
                    str=not_empty_sentences[0];
                    for (cnt=1;cnt<nb_not_empty_sentences-1;cnt++)
                    {
                        str+=this.obj_details_language.list_sentences_comma+not_empty_sentences[cnt];
                    }
                    str+=this.obj_details_language.list_sentences_and+not_empty_sentences[cnt];
                    return str;
            }
        }
        #endregion

        #region parse_visibility_group
        private string parse_visibility_group(ClassVisibility obj_visibility)
        {
            if (obj_visibility==null)
                return "";
            if (obj_visibility.b_no_data)
                return "";

            string str="";
            string str_prefix="";
            switch (obj_visibility.prefix)
            {
                case -1:
                    str_prefix=this.obj_details_language.visibility_less_than;
                    break;
                case 1:
                    str_prefix=this.obj_details_language.visibility_greater_than;
                    break;
            }
            str+=str_prefix
                +this.get_length(this.obj_options.length_unit,obj_visibility.length);

            if (obj_visibility.dir!="")
            {
                str+=this.obj_details_language.visibility_to
                    +this.get_wind_dir_short_long(obj_visibility.dir);
            }

            return str;
        }
        #endregion
      
        #region print_pretty_visibility
        private string print_pretty_visibility()
        {
            if (this.obj_metar.visibility_group_number==0)
                return "";
            string[] str_visibility=new string[this.obj_metar.visibility_group_number];
            for (int cnt=0;cnt<this.obj_metar.visibility_group_number;cnt++)
            {
                if (cnt>0)
                {
                    if (this.obj_metar.visibility_array[cnt].length.Meter==this.obj_metar.visibility_array[cnt-1].length.Meter)
                    {
                        str_visibility[cnt]="";
                        continue;
                    }
                }
                str_visibility[cnt]=this.parse_visibility_group(this.obj_metar.visibility_array[cnt]);
            }
            string str=this.list_sentences(str_visibility);
            if (str!="")
                str=this.obj_details_language.visibility+str+".";
            return str;
        }
        #endregion

        #region parse_precip
        private string parse_precip(ClassHeight obj_height)
        {
            if (obj_height==null)
                return "";
            if (obj_height.Mm==0)
                return "";
            if (obj_height.Mm<0)
                return this.obj_details_language.precip_a_trace;
            // else
            return get_height(this.obj_options.precipitation_height_unit,obj_height);
        }
        #endregion

        #region print_pretty_precipitation
        private string print_pretty_precipitation()
        {
            if (this.obj_metar.precipitation.b_no_data)
                return "";
            string str1h="";
            string str6h="";
            string str24h="";
            string strsnow="";
            string str="";
            str1h=this.parse_precip(this.obj_metar.precipitation.height);
            if (str1h!="")
                str1h+=this.obj_details_language.precip_last_hour;
            str6h=this.parse_precip(this.obj_metar.precipitation.height_6h);
            if (str6h!="")
                str6h+=this.obj_details_language.precip_last_6_hours;
            str24h=this.parse_precip(this.obj_metar.precipitation.height_24h);
            if (str24h!="")
                str24h+=this.obj_details_language.precip_last_24_hours;
            strsnow=this.parse_precip(this.obj_metar.precipitation.height_snow);
            if (strsnow!="")
                strsnow+=this.obj_details_language.precip_snow;

            str=this.list_sentences(new string[]{str1h,str6h,str24h,strsnow});
            if (str!="")
                str=this.obj_details_language.precip_there_was+str+".";
            return str;
        }
        #endregion

        #region print_pretty_temp_min_max
        private string print_pretty_temp_min_max()
        {
            string str="";
            if (this.obj_metar.temperature.temp_min_max.max6h.is_set()&&this.obj_metar.temperature.temp_min_max.min6h.is_set())
                str+=String.Format(this.obj_details_language.temp_min_max_6_hours,
                                    this.obj_metar.temperature.temp_min_max.min6h.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit),
                                    this.obj_metar.temperature.temp_min_max.max6h.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit));
            else if (this.obj_metar.temperature.temp_min_max.max6h.is_set())
                str+=String.Format(this.obj_details_language.temp_max_6_hours,
                    this.obj_metar.temperature.temp_min_max.max6h.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit));
            else if (this.obj_metar.temperature.temp_min_max.min6h.is_set())
                str+=String.Format(this.obj_details_language.temp_min_6_hours,
                    this.obj_metar.temperature.temp_min_max.min6h.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit));

            if (this.obj_metar.temperature.temp_min_max.max24h.is_set()&&this.obj_metar.temperature.temp_min_max.min24h.is_set())
                str+=String.Format(this.obj_details_language.temp_min_max_24_hours,
                    this.obj_metar.temperature.temp_min_max.min24h.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit),
                    this.obj_metar.temperature.temp_min_max.max24h.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit));
            else if (this.obj_metar.temperature.temp_min_max.max24h.is_set())
                str+=String.Format(this.obj_details_language.temp_max_24_hours,
                    this.obj_metar.temperature.temp_min_max.max24h.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit));
            else if (this.obj_metar.temperature.temp_min_max.min24h.is_set())
                str+=String.Format(this.obj_details_language.temp_min_24_hours,
                    this.obj_metar.temperature.temp_min_max.min24h.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit));

            return str;
        }
        #endregion

        #region parse_runway_group
        private string parse_runway_group(ClassRunway obj_runway)
        {
            if (obj_runway==null)
                return "";
            if (obj_runway.b_no_data)
                return "";
            string str="";
            string approach="";

            switch (obj_runway.approach)
            {
                case "L":
                    approach=this.obj_details_language.runway_left;
                    break;
                case "C":
                    approach=this.obj_details_language.runway_central;
                    break;
                case "R":
                    approach=this.obj_details_language.runway_right;
                    break;
                    // default: //error
            }
            if (obj_runway.min_length.Meter!=0)
            {
                str+=this.obj_details_language.runway_between
                    +this.get_length(this.obj_options.length_unit,obj_runway.min_length)
                    +this.get_runway_tendency_description(obj_runway.min_tendency)
                    +this.obj_details_language.and
                    +this.get_length(this.obj_options.length_unit,obj_runway.max_length)
                    +this.get_runway_tendency_description(obj_runway.max_tendency)
                    +this.obj_details_language.runway_for_runway
                    +obj_runway.nr
                    +approach;
                    
            }
            else
            {
                str+=this.get_length(this.obj_options.length_unit,obj_runway.length)
                    +this.get_runway_tendency_description(obj_runway.tendency)
                    +this.obj_details_language.runway_for_runway
                    +obj_runway.nr
                    +approach;
            }

            return str;
        }
        #endregion

        #region print_pretty_runway
        private string print_pretty_runway()
        {
            if (this.obj_metar.runway_group_number==0)
                return "";
            string[] str_runway=new string[this.obj_metar.runway_group_number];
            for (int cnt=0;cnt<this.obj_metar.runway_group_number;cnt++)
                str_runway[cnt]=this.parse_runway_group(this.obj_metar.runway_array[cnt]);
            string str=this.list_sentences(str_runway);
            if (str!="")
                str=this.obj_details_language.runway_visibility+str+".";
            return str;
        }
        #endregion

        #region parse_weather_group
        private string parse_weather_group(ClassWeather obj_weather)
        {
            if (obj_weather==null)
                return "";
            if (obj_weather.b_no_data)
                return "";
            string str="";
            if (obj_weather.descriptor!="")
            {
                if ((obj_weather.descriptor=="TS")&&(obj_weather.precipitation!=""))
                {
                    /* Special case for thunderstorms. They use the extra
                    * word 'with' between the descriptor (which would be
                    * 'thunderstorm' in this case) and the precipitation. 
                    * But this is only true if there's also precipitation. 
                    */
                    str+=this.get_weather_descriptor_description(obj_weather.descriptor)
                        +this.obj_details_language.with;
                }
                else
                    str+=this.get_weather_descriptor_description(obj_weather.descriptor);

            }
            /* If the intensity is non-empty, we just add it. If not, it could
            * mean that we're dealing with some 'moderate' precipitation. 
            * If so, 'precipitation' can't be empty. 
            */
            if (obj_weather.intensity!="")
            {
                str+=this.get_weather_descriptor_description(obj_weather.intensity);
            }
            else if (obj_weather.precipitation!="")
            {
                str+=this.get_weather_descriptor_description(" ");
            }
            if (obj_weather.precipitation!="")
            {
                string str_precip="";
                for(int cnt=0;cnt<obj_weather.precipitation.Length/2;cnt++)
                {
                    if (str_precip!="")
                        str_precip+=", ";
                    str_precip+=this.get_weather_descriptor_description(obj_weather.precipitation.Substring(2*cnt,2));
                }
                str+=str_precip;
            }
            else if (obj_weather.obscuration!="")
            {
                str+=this.get_weather_descriptor_description(obj_weather.obscuration);
            }
            else if (obj_weather.other!="")
            {
                str+=this.get_weather_descriptor_description(obj_weather.other);
            }
            /* 'proximity' can only be 'VC'. We test for it here instead of
             *  earlier because it should be put last. 
             */
            if (obj_weather.proximity!="")
            {
                str+=this.get_weather_descriptor_description(obj_weather.proximity);
            }
            return str;
        }
        #endregion

        #region print_pretty_weather
        private string print_pretty_weather()
        {
            if (this.obj_metar.weather_group_number==0)
                return "";
            //we have at least this.obj_metar.weather_array[0]
            string str=this.obj_details_language.currently
                      +this.parse_weather_group(this.obj_metar.weather_array[0]);
            for (int cnt=1;cnt<this.obj_metar.weather_group_number;cnt++)
            {
                str+=this.obj_details_language.plus
                    +this.parse_weather_group(this.obj_metar.weather_array[cnt]);
            }
            if (str!="")
                str+=".";
            return str;
        }
        #endregion

        public void set_language(string language_filename)
        {
            this.obj_details_language=ClassDetailsLanguage.load(language_filename);
        }
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormDetails));
            this.textBox_details = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox_details
            // 
            this.textBox_details.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_details.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.textBox_details.Location = new System.Drawing.Point(0, 0);
            this.textBox_details.Multiline = true;
            this.textBox_details.Name = "textBox_details";
            this.textBox_details.ReadOnly = true;
            this.textBox_details.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_details.Size = new System.Drawing.Size(304, 166);
            this.textBox_details.TabIndex = 0;
            this.textBox_details.Text = "No data";
            // 
            // FormDetails
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(304, 166);
            this.Controls.Add(this.textBox_details);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Details";
            this.TopMost = true;
            this.Closing += new System.ComponentModel.CancelEventHandler(this.FormDetails_Closing);
            this.ResumeLayout(false);

        }
		#endregion


	}
}
