/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for ClassPressure.
	/// </summary>
	public class ClassPressure:ClassWeatherInformation
	{
        public enum UNITS{INHG=0,MMHG,HPA,ATM}
        private double inhg=0;
        private double mmhg=0;
        private double hpa=0;
        private double atm=0;

        public double Inhg
        {
            get
            {
                return this.inhg;
            }
            set
            {
                this.inhg=value;
                this.Hpa=this.inhg/0.02953;
            }
        }
        public double Mmhg
        {
            get
            {
                return this.mmhg;
            }
            set
            {
                this.mmhg=value;
                this.Hpa=this.mmhg/0.75006;
            }
        }
        public double Hpa
        {
            get
            {
                return this.hpa;
            }
            set
            {
                this.hpa=value;
                this.mmhg = this.hpa * 0.75006;
                this.inhg = this.hpa * 0.02953;
                this.atm  = this.hpa * 9.8692e-4;
            }
        }
        public double Atm
        {
            get
            {
                return this.atm;
            }
            set
            {
                this.atm=value;
                this.Hpa=this.atm/9.8692e-4;
            }
        }

		public ClassPressure()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
