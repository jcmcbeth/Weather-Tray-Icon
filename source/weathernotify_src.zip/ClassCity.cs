/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for ClassCity.
	/// </summary>
    public class ClassCity
    {
        public string name="";
        public string code="";
        public string country="";
        public string country_code="";

        public ClassCity()
        {
        }
        public ClassCity(string code,string name,string country,string country_code)
        {
            this.name=name;
            this.code=code;
            this.country=country;
            this.country_code=country_code;
        }

        /// <summary>
        /// extract city/code list from config file
        /// </summary>
        /// <param name="str_filename">full path</param>
        /// <returns>null on error</returns>
        public static ClassCity[] load_from_config_file(string str_filename)
        {
            // use the stations.db of phpwheather
            string[] lines=file_access.read_lines(str_filename);
            if (lines==null)
                return null;
            string[] fields;
            //LFRB:Brest:France:FR
            System.Collections.ArrayList al=new System.Collections.ArrayList(lines.Length);
            for(int cnt=0;cnt<lines.Length;cnt++)
            {
                fields=lines[cnt].Split(':');
                if (fields.Length!=4)
                    continue;
                al.Add(new ClassCity(fields[0].Trim(),fields[1].Trim(),fields[2].Trim(),fields[3].Trim()));
            }
            if (al.Count==0)
                return null;
            return ((ClassCity[])al.ToArray(typeof(ClassCity)));
        }
        /// <summary>
        /// get City object from city name and country
        /// </summary>
        /// <param name="str_city_name">city name</param>
        /// <returns>ClassCity on success, null on error</returns>
        public static ClassCity get_city_from_city_name_and_country(ref ClassCity[] array_city,string str_city_name,string str_country)
        {
            for (int cnt=0;cnt<array_city.Length;cnt++)
            {
                if((array_city[cnt].name==str_city_name)&&(array_city[cnt].country==str_country))
                    return array_city[cnt];
            }
            return null;
        }
    }
}
