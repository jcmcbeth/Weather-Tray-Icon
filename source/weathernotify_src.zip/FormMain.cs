/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WeatherNotify
{

    public class FormMain : System.Windows.Forms.Form
    {
        private System.ComponentModel.IContainer components;
        
        private const string IMG_DIRECTORY="icons\\";
        private const string CONFIG_FILENAME="options.xml";
        private const string LANGUAGE_DIRECTORY="languages\\";
        private const string LANGUAGE_INTERFACE_DIRECTORY="languages\\interface\\";
        private const string CITY_FILENAME="stations.db";

        private ClassMetarDownload obj_metar_download=null;
        private ClassInterfaceLanguage obj_interface_language=null;
        private ClassOptions obj_options;

        private FormWeatherView frm_weather_view;
        private FormDetails frm_details=null;
        private System.Windows.Forms.NotifyIcon[] array_NotifyIcon;
        
        private ClassCity[] pcity_list;
        private enum NOTIFY_ICON_POS{WEATHER=0,TEMP,WIND_IMG,WIND_DATA};
        private int notify_icon_number=4;
        private bool b_closed_forced=false;
        private string exe_path="";
        private string last_raw_metar="";
        private string[] report_language_available=null;
        


        private System.Windows.Forms.ContextMenu contextMenu_main;
        private System.Windows.Forms.MenuItem menuItem_exit;
        private System.Windows.Forms.MenuItem menuItem_about;
        private System.Windows.Forms.MenuItem menuItem_options;
        private System.Windows.Forms.MenuItem menuItem_hide_show;
        private System.Windows.Forms.Button button_apply;
        private System.Windows.Forms.GroupBox groupBox_notifyicon;
        private System.Windows.Forms.GroupBox groupBox_Window;
        private System.Windows.Forms.CheckBox checkBox_wind_speed;
        private System.Windows.Forms.CheckBox checkBox_wind_dir;
        private System.Windows.Forms.CheckBox checkBox_clouds;
        private System.Windows.Forms.CheckBox checkBox_temp;
        private System.Windows.Forms.CheckBox checkBox_w_topmost;
        private System.Windows.Forms.CheckBox checkBox_w_wind;
        private System.Windows.Forms.CheckBox checkBox_w_clouds;
        private System.Windows.Forms.CheckBox checkBox_w_temp;
        private System.Windows.Forms.TrackBar trackBar_w_opacity;
        private System.Windows.Forms.Label label_window_opacity;
        private System.Windows.Forms.ComboBox comboBox_cities;
        private System.Windows.Forms.Label label_city;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.GroupBox groupBox_current_state;
        private System.Windows.Forms.Label label_current_state;
        private System.Windows.Forms.CheckBox checkBox_w_pressure;
        private System.Windows.Forms.MenuItem menuItem_details;
        private System.Windows.Forms.GroupBox groupBox_units;
        private System.Windows.Forms.ComboBox comboBox_pressure_unit;
        private System.Windows.Forms.Label label_pressure_unit;
        private System.Windows.Forms.ComboBox comboBox_wind_unit;
        private System.Windows.Forms.ComboBox comboBox_temp_unit;
        private System.Windows.Forms.Label label_temp_unit;
        private System.Windows.Forms.Label label_wind_unit;
        private System.Windows.Forms.Label label_length_unit;
        private System.Windows.Forms.ComboBox comboBox_length_unit;
        private System.Windows.Forms.ComboBox comboBox_precipitation_height_unit;
        private System.Windows.Forms.ComboBox comboBox_height_unit;
        private System.Windows.Forms.ComboBox comboBox_orientation;
        private System.Windows.Forms.Label label_orientation;
        private System.Windows.Forms.GroupBox groupBox_language;
        private System.Windows.Forms.ComboBox comboBox_language;
        private System.Windows.Forms.Label label_height_unit;
        private System.Windows.Forms.Label label_precipitation_height_unit;
        private System.Windows.Forms.MenuItem menuItem_separator;


        #region constructor

        public FormMain()
        {
            InitializeComponent();
            XPStyle.MakeXPStyle(this);

            // get exe path
            this.exe_path=System.Windows.Forms.Application.ExecutablePath;
            int last_pos=this.exe_path.LastIndexOf("\\");
            if (last_pos>0)
                this.exe_path=this.exe_path.Substring(0,last_pos+1);

            // metar download
            this.obj_metar_download=new ClassMetarDownload();
            this.obj_metar_download.event_MetarDownload_Arrival+=new MetarDownload_Arrival_EventHandler(obj_metar_download_event_MetarDownload_Arrival);
            this.obj_metar_download.event_MetarDownload_Error+=new MetarDownload_Error_EventHandler(obj_metar_download_event_MetarDownload_Error);
            
            this.obj_options=ClassOptions.load(this.exe_path+CONFIG_FILENAME); 
            this.frm_details=new FormDetails();
            this.frm_weather_view=new FormWeatherView(this,ref this.obj_options,this.frm_details);
            this.update_language_interface();
            
            int cpt;

            // notify icons
            if (this.components==null)
                this.components = new System.ComponentModel.Container();
            this.array_NotifyIcon=new System.Windows.Forms.NotifyIcon[notify_icon_number];
            for (cpt=0;cpt<notify_icon_number;cpt++)
            {
                this.array_NotifyIcon[cpt] = new System.Windows.Forms.NotifyIcon(this.components);
                this.array_NotifyIcon[cpt].ContextMenu=this.contextMenu_main;
                this.array_NotifyIcon[cpt].DoubleClick+=new EventHandler(NotifyIcon_DoubleClick);
            }
            this.array_NotifyIcon[(int)NOTIFY_ICON_POS.WEATHER].Text =this.obj_interface_language.weather;
            this.array_NotifyIcon[(int)NOTIFY_ICON_POS.TEMP].Text = this.obj_interface_language.temperature;
            this.array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_IMG].Text = this.obj_interface_language.wind_direction;
            this.array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_DATA].Text = this.obj_interface_language.wind_speed;

            // city
            this.pcity_list=ClassCity.load_from_config_file(this.exe_path+CITY_FILENAME);

            //report language
            try
            {
                this.report_language_available=System.IO.Directory.GetFiles(this.exe_path+LANGUAGE_DIRECTORY,"*.xml");
                if (this.report_language_available!=null)
                {
                    for (cpt=0;cpt<this.report_language_available.Length;cpt++)
                        this.report_language_available[cpt]=System.IO.Path.GetFileNameWithoutExtension(this.report_language_available[cpt]);
                    this.comboBox_language.Items.AddRange(this.report_language_available);
                }
            }
            catch
            {
                this.report_language_available=null;
            }

            // update options
            if (this.pcity_list!=null)
            {
                if (this.pcity_list.Length!=0)
                {
                    for (int cnt=0;cnt<this.pcity_list.Length;cnt++)
                    this.comboBox_cities.Items.Add(this.pcity_list[cnt].country +" : "+ this.pcity_list[cnt].name);
                    this.comboBox_cities.SelectedIndex=0;
                }
            }
            this.comboBox_orientation.SelectedIndex=(int)this.obj_options.window_orientation;
            this.comboBox_temp_unit.SelectedIndex=(int)this.obj_options.temp_unit;
            this.comboBox_wind_unit.SelectedIndex=(int)this.obj_options.wind_unit;
            this.comboBox_pressure_unit.SelectedIndex=(int)this.obj_options.pressure_unit;
            this.comboBox_length_unit.SelectedIndex=(int)this.obj_options.length_unit;
            this.comboBox_precipitation_height_unit.SelectedIndex=(int)this.obj_options.precipitation_height_unit;
            this.comboBox_height_unit.SelectedIndex=(int)this.obj_options.height_unit;
            this.comboBox_language.Text=this.obj_options.report_language;
            this.frm_details.set_language(this.exe_path+LANGUAGE_DIRECTORY+this.obj_options.report_language+".xml");

            this.checkBox_clouds.Checked=this.obj_options.show_clouds_in_satusbar;
            this.checkBox_temp.Checked=this.obj_options.show_temp_in_satusbar;
            this.checkBox_wind_dir.Checked=this.obj_options.show_wind_dir_in_satusbar;
            this.checkBox_wind_speed.Checked=this.obj_options.show_wind_speed_in_satusbar;
            this.checkBox_w_clouds.Checked=this.obj_options.show_clouds_in_window;
            this.checkBox_w_temp.Checked=this.obj_options.show_temp_in_window;
            this.checkBox_w_wind.Checked=this.obj_options.show_wind_in_window;
            this.checkBox_w_pressure.Checked=this.obj_options.show_pressure_in_window;
            this.checkBox_w_topmost.Checked=this.obj_options.top_most;
            this.trackBar_w_opacity.Value=(int)(this.obj_options.opacity*100);

            int index=this.comboBox_cities.FindStringExact(this.obj_options.city.country+" : "+this.obj_options.city.name);
            if (index<0)
                index=0;
            if (this.comboBox_cities.Items.Count>0)
                this.comboBox_cities.SelectedIndex=index;
        }
        #endregion

        protected override void Dispose( bool disposing )
        {
            this.obj_metar_download.event_MetarDownload_Arrival-=new MetarDownload_Arrival_EventHandler(obj_metar_download_event_MetarDownload_Arrival);
            this.obj_metar_download.event_MetarDownload_Error-=new MetarDownload_Error_EventHandler(obj_metar_download_event_MetarDownload_Error);
            if( disposing )
            {
                if (components != null) 
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }


        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormMain));
            this.contextMenu_main = new System.Windows.Forms.ContextMenu();
            this.menuItem_hide_show = new System.Windows.Forms.MenuItem();
            this.menuItem_details = new System.Windows.Forms.MenuItem();
            this.menuItem_options = new System.Windows.Forms.MenuItem();
            this.menuItem_about = new System.Windows.Forms.MenuItem();
            this.menuItem_separator = new System.Windows.Forms.MenuItem();
            this.menuItem_exit = new System.Windows.Forms.MenuItem();
            this.button_apply = new System.Windows.Forms.Button();
            this.groupBox_notifyicon = new System.Windows.Forms.GroupBox();
            this.checkBox_wind_speed = new System.Windows.Forms.CheckBox();
            this.checkBox_wind_dir = new System.Windows.Forms.CheckBox();
            this.checkBox_clouds = new System.Windows.Forms.CheckBox();
            this.checkBox_temp = new System.Windows.Forms.CheckBox();
            this.groupBox_Window = new System.Windows.Forms.GroupBox();
            this.comboBox_orientation = new System.Windows.Forms.ComboBox();
            this.label_orientation = new System.Windows.Forms.Label();
            this.checkBox_w_pressure = new System.Windows.Forms.CheckBox();
            this.label_window_opacity = new System.Windows.Forms.Label();
            this.trackBar_w_opacity = new System.Windows.Forms.TrackBar();
            this.checkBox_w_topmost = new System.Windows.Forms.CheckBox();
            this.checkBox_w_wind = new System.Windows.Forms.CheckBox();
            this.checkBox_w_clouds = new System.Windows.Forms.CheckBox();
            this.checkBox_w_temp = new System.Windows.Forms.CheckBox();
            this.comboBox_cities = new System.Windows.Forms.ComboBox();
            this.label_city = new System.Windows.Forms.Label();
            this.button_cancel = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.groupBox_current_state = new System.Windows.Forms.GroupBox();
            this.label_current_state = new System.Windows.Forms.Label();
            this.groupBox_units = new System.Windows.Forms.GroupBox();
            this.comboBox_height_unit = new System.Windows.Forms.ComboBox();
            this.label_height_unit = new System.Windows.Forms.Label();
            this.comboBox_length_unit = new System.Windows.Forms.ComboBox();
            this.comboBox_precipitation_height_unit = new System.Windows.Forms.ComboBox();
            this.label_length_unit = new System.Windows.Forms.Label();
            this.label_precipitation_height_unit = new System.Windows.Forms.Label();
            this.comboBox_pressure_unit = new System.Windows.Forms.ComboBox();
            this.label_pressure_unit = new System.Windows.Forms.Label();
            this.comboBox_wind_unit = new System.Windows.Forms.ComboBox();
            this.comboBox_temp_unit = new System.Windows.Forms.ComboBox();
            this.label_temp_unit = new System.Windows.Forms.Label();
            this.label_wind_unit = new System.Windows.Forms.Label();
            this.groupBox_language = new System.Windows.Forms.GroupBox();
            this.comboBox_language = new System.Windows.Forms.ComboBox();
            this.groupBox_notifyicon.SuspendLayout();
            this.groupBox_Window.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_w_opacity)).BeginInit();
            this.groupBox_current_state.SuspendLayout();
            this.groupBox_units.SuspendLayout();
            this.groupBox_language.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenu_main
            // 
            this.contextMenu_main.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                             this.menuItem_hide_show,
                                                                                             this.menuItem_details,
                                                                                             this.menuItem_options,
                                                                                             this.menuItem_about,
                                                                                             this.menuItem_separator,
                                                                                             this.menuItem_exit});
            // 
            // menuItem_hide_show
            // 
            this.menuItem_hide_show.Index = 0;
            this.menuItem_hide_show.Text = "Hide/Show";
            this.menuItem_hide_show.Click += new System.EventHandler(this.menuItem_hide_show_Click);
            // 
            // menuItem_details
            // 
            this.menuItem_details.Index = 1;
            this.menuItem_details.Text = "Details";
            this.menuItem_details.Click += new System.EventHandler(this.menuItem_details_Click);
            // 
            // menuItem_options
            // 
            this.menuItem_options.Index = 2;
            this.menuItem_options.Text = "Options";
            this.menuItem_options.Click += new System.EventHandler(this.menuItem_options_Click);
            // 
            // menuItem_about
            // 
            this.menuItem_about.Index = 3;
            this.menuItem_about.Text = "About";
            this.menuItem_about.Click += new System.EventHandler(this.menuItem_about_Click);
            // 
            // menuItem_separator
            // 
            this.menuItem_separator.Index = 4;
            this.menuItem_separator.Text = "-";
            // 
            // menuItem_exit
            // 
            this.menuItem_exit.Index = 5;
            this.menuItem_exit.Text = "Exit";
            this.menuItem_exit.Click += new System.EventHandler(this.menuItem_exit_Click);
            // 
            // button_apply
            // 
            this.button_apply.Location = new System.Drawing.Point(16, 384);
            this.button_apply.Name = "button_apply";
            this.button_apply.TabIndex = 8;
            this.button_apply.Text = "Apply";
            this.button_apply.Click += new System.EventHandler(this.button_apply_Click);
            // 
            // groupBox_notifyicon
            // 
            this.groupBox_notifyicon.Controls.Add(this.checkBox_wind_speed);
            this.groupBox_notifyicon.Controls.Add(this.checkBox_wind_dir);
            this.groupBox_notifyicon.Controls.Add(this.checkBox_clouds);
            this.groupBox_notifyicon.Controls.Add(this.checkBox_temp);
            this.groupBox_notifyicon.Location = new System.Drawing.Point(8, 104);
            this.groupBox_notifyicon.Name = "groupBox_notifyicon";
            this.groupBox_notifyicon.Size = new System.Drawing.Size(120, 88);
            this.groupBox_notifyicon.TabIndex = 9;
            this.groupBox_notifyicon.TabStop = false;
            this.groupBox_notifyicon.Text = "Notify Icons";
            // 
            // checkBox_wind_speed
            // 
            this.checkBox_wind_speed.Location = new System.Drawing.Point(8, 64);
            this.checkBox_wind_speed.Name = "checkBox_wind_speed";
            this.checkBox_wind_speed.Size = new System.Drawing.Size(104, 16);
            this.checkBox_wind_speed.TabIndex = 7;
            this.checkBox_wind_speed.Text = "Wind Speed";
            // 
            // checkBox_wind_dir
            // 
            this.checkBox_wind_dir.Location = new System.Drawing.Point(8, 48);
            this.checkBox_wind_dir.Name = "checkBox_wind_dir";
            this.checkBox_wind_dir.Size = new System.Drawing.Size(104, 16);
            this.checkBox_wind_dir.TabIndex = 6;
            this.checkBox_wind_dir.Text = "Wind Direction";
            // 
            // checkBox_clouds
            // 
            this.checkBox_clouds.Location = new System.Drawing.Point(8, 16);
            this.checkBox_clouds.Name = "checkBox_clouds";
            this.checkBox_clouds.Size = new System.Drawing.Size(104, 16);
            this.checkBox_clouds.TabIndex = 4;
            this.checkBox_clouds.Text = "Clouds";
            // 
            // checkBox_temp
            // 
            this.checkBox_temp.Location = new System.Drawing.Point(8, 32);
            this.checkBox_temp.Name = "checkBox_temp";
            this.checkBox_temp.Size = new System.Drawing.Size(104, 16);
            this.checkBox_temp.TabIndex = 5;
            this.checkBox_temp.Text = "Temperature";
            // 
            // groupBox_Window
            // 
            this.groupBox_Window.Controls.Add(this.comboBox_orientation);
            this.groupBox_Window.Controls.Add(this.label_orientation);
            this.groupBox_Window.Controls.Add(this.checkBox_w_pressure);
            this.groupBox_Window.Controls.Add(this.label_window_opacity);
            this.groupBox_Window.Controls.Add(this.trackBar_w_opacity);
            this.groupBox_Window.Controls.Add(this.checkBox_w_topmost);
            this.groupBox_Window.Controls.Add(this.checkBox_w_wind);
            this.groupBox_Window.Controls.Add(this.checkBox_w_clouds);
            this.groupBox_Window.Controls.Add(this.checkBox_w_temp);
            this.groupBox_Window.Location = new System.Drawing.Point(136, 40);
            this.groupBox_Window.Name = "groupBox_Window";
            this.groupBox_Window.Size = new System.Drawing.Size(144, 192);
            this.groupBox_Window.TabIndex = 10;
            this.groupBox_Window.TabStop = false;
            this.groupBox_Window.Text = "Window";
            // 
            // comboBox_orientation
            // 
            this.comboBox_orientation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_orientation.Items.AddRange(new object[] {
                                                                      "Horizontal",
                                                                      "Vertical"});
            this.comboBox_orientation.Location = new System.Drawing.Point(8, 168);
            this.comboBox_orientation.Name = "comboBox_orientation";
            this.comboBox_orientation.Size = new System.Drawing.Size(128, 21);
            this.comboBox_orientation.TabIndex = 17;
            // 
            // label_orientation
            // 
            this.label_orientation.Location = new System.Drawing.Point(8, 152);
            this.label_orientation.Name = "label_orientation";
            this.label_orientation.Size = new System.Drawing.Size(128, 16);
            this.label_orientation.TabIndex = 16;
            this.label_orientation.Text = "Orientation";
            // 
            // checkBox_w_pressure
            // 
            this.checkBox_w_pressure.Location = new System.Drawing.Point(8, 64);
            this.checkBox_w_pressure.Name = "checkBox_w_pressure";
            this.checkBox_w_pressure.Size = new System.Drawing.Size(104, 16);
            this.checkBox_w_pressure.TabIndex = 11;
            this.checkBox_w_pressure.Text = "Pressure";
            // 
            // label_window_opacity
            // 
            this.label_window_opacity.Location = new System.Drawing.Point(8, 112);
            this.label_window_opacity.Name = "label_window_opacity";
            this.label_window_opacity.Size = new System.Drawing.Size(128, 16);
            this.label_window_opacity.TabIndex = 13;
            this.label_window_opacity.Text = "Window Opacity";
            // 
            // trackBar_w_opacity
            // 
            this.trackBar_w_opacity.AutoSize = false;
            this.trackBar_w_opacity.Location = new System.Drawing.Point(8, 128);
            this.trackBar_w_opacity.Maximum = 100;
            this.trackBar_w_opacity.Name = "trackBar_w_opacity";
            this.trackBar_w_opacity.Size = new System.Drawing.Size(128, 24);
            this.trackBar_w_opacity.TabIndex = 12;
            this.trackBar_w_opacity.Tag = "Opacity";
            this.trackBar_w_opacity.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar_w_opacity.Value = 80;
            // 
            // checkBox_w_topmost
            // 
            this.checkBox_w_topmost.Location = new System.Drawing.Point(8, 96);
            this.checkBox_w_topmost.Name = "checkBox_w_topmost";
            this.checkBox_w_topmost.Size = new System.Drawing.Size(128, 16);
            this.checkBox_w_topmost.TabIndex = 12;
            this.checkBox_w_topmost.Text = "Top Most Window";
            // 
            // checkBox_w_wind
            // 
            this.checkBox_w_wind.Location = new System.Drawing.Point(8, 48);
            this.checkBox_w_wind.Name = "checkBox_w_wind";
            this.checkBox_w_wind.Size = new System.Drawing.Size(104, 16);
            this.checkBox_w_wind.TabIndex = 10;
            this.checkBox_w_wind.Text = "Wind";
            // 
            // checkBox_w_clouds
            // 
            this.checkBox_w_clouds.Location = new System.Drawing.Point(8, 16);
            this.checkBox_w_clouds.Name = "checkBox_w_clouds";
            this.checkBox_w_clouds.Size = new System.Drawing.Size(104, 16);
            this.checkBox_w_clouds.TabIndex = 8;
            this.checkBox_w_clouds.Text = "Clouds";
            // 
            // checkBox_w_temp
            // 
            this.checkBox_w_temp.Location = new System.Drawing.Point(8, 32);
            this.checkBox_w_temp.Name = "checkBox_w_temp";
            this.checkBox_w_temp.Size = new System.Drawing.Size(104, 16);
            this.checkBox_w_temp.TabIndex = 9;
            this.checkBox_w_temp.Text = "Temperature";
            // 
            // comboBox_cities
            // 
            this.comboBox_cities.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_cities.Location = new System.Drawing.Point(8, 16);
            this.comboBox_cities.Name = "comboBox_cities";
            this.comboBox_cities.Size = new System.Drawing.Size(272, 21);
            this.comboBox_cities.TabIndex = 12;
            // 
            // label_city
            // 
            this.label_city.Location = new System.Drawing.Point(8, 0);
            this.label_city.Name = "label_city";
            this.label_city.Size = new System.Drawing.Size(120, 16);
            this.label_city.TabIndex = 13;
            this.label_city.Text = "Country : City";
            // 
            // button_cancel
            // 
            this.button_cancel.Location = new System.Drawing.Point(104, 384);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.TabIndex = 14;
            this.button_cancel.Text = "Cancel";
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(192, 384);
            this.button_exit.Name = "button_exit";
            this.button_exit.TabIndex = 19;
            this.button_exit.Text = "Exit";
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // groupBox_current_state
            // 
            this.groupBox_current_state.Controls.Add(this.label_current_state);
            this.groupBox_current_state.Location = new System.Drawing.Point(8, 40);
            this.groupBox_current_state.Name = "groupBox_current_state";
            this.groupBox_current_state.Size = new System.Drawing.Size(120, 64);
            this.groupBox_current_state.TabIndex = 20;
            this.groupBox_current_state.TabStop = false;
            this.groupBox_current_state.Text = "Current State";
            // 
            // label_current_state
            // 
            this.label_current_state.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_current_state.Location = new System.Drawing.Point(3, 16);
            this.label_current_state.Name = "label_current_state";
            this.label_current_state.Size = new System.Drawing.Size(114, 45);
            this.label_current_state.TabIndex = 0;
            this.label_current_state.Text = "Stopped";
            this.label_current_state.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox_units
            // 
            this.groupBox_units.Controls.Add(this.comboBox_height_unit);
            this.groupBox_units.Controls.Add(this.label_height_unit);
            this.groupBox_units.Controls.Add(this.comboBox_length_unit);
            this.groupBox_units.Controls.Add(this.comboBox_precipitation_height_unit);
            this.groupBox_units.Controls.Add(this.label_length_unit);
            this.groupBox_units.Controls.Add(this.label_precipitation_height_unit);
            this.groupBox_units.Controls.Add(this.comboBox_pressure_unit);
            this.groupBox_units.Controls.Add(this.label_pressure_unit);
            this.groupBox_units.Controls.Add(this.comboBox_wind_unit);
            this.groupBox_units.Controls.Add(this.comboBox_temp_unit);
            this.groupBox_units.Controls.Add(this.label_temp_unit);
            this.groupBox_units.Controls.Add(this.label_wind_unit);
            this.groupBox_units.Location = new System.Drawing.Point(8, 232);
            this.groupBox_units.Name = "groupBox_units";
            this.groupBox_units.Size = new System.Drawing.Size(272, 144);
            this.groupBox_units.TabIndex = 23;
            this.groupBox_units.TabStop = false;
            this.groupBox_units.Text = "Units";
            // 
            // comboBox_height_unit
            // 
            this.comboBox_height_unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_height_unit.ItemHeight = 13;
            this.comboBox_height_unit.Items.AddRange(new object[] {
                                                                      "FEET",
                                                                      "KM",
                                                                      "METER",
                                                                      "MILES"});
            this.comboBox_height_unit.Location = new System.Drawing.Point(160, 112);
            this.comboBox_height_unit.Name = "comboBox_height_unit";
            this.comboBox_height_unit.Size = new System.Drawing.Size(96, 21);
            this.comboBox_height_unit.TabIndex = 34;
            // 
            // label_height_unit
            // 
            this.label_height_unit.Location = new System.Drawing.Point(160, 96);
            this.label_height_unit.Name = "label_height_unit";
            this.label_height_unit.Size = new System.Drawing.Size(104, 16);
            this.label_height_unit.TabIndex = 33;
            this.label_height_unit.Text = "Height";
            // 
            // comboBox_length_unit
            // 
            this.comboBox_length_unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_length_unit.ItemHeight = 13;
            this.comboBox_length_unit.Items.AddRange(new object[] {
                                                                      "FEET",
                                                                      "KM",
                                                                      "METER",
                                                                      "MILES"});
            this.comboBox_length_unit.Location = new System.Drawing.Point(160, 72);
            this.comboBox_length_unit.Name = "comboBox_length_unit";
            this.comboBox_length_unit.Size = new System.Drawing.Size(96, 21);
            this.comboBox_length_unit.TabIndex = 32;
            // 
            // comboBox_precipitation_height_unit
            // 
            this.comboBox_precipitation_height_unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_precipitation_height_unit.ItemHeight = 13;
            this.comboBox_precipitation_height_unit.Items.AddRange(new object[] {
                                                                                    "INCH",
                                                                                    "MM"});
            this.comboBox_precipitation_height_unit.Location = new System.Drawing.Point(16, 112);
            this.comboBox_precipitation_height_unit.Name = "comboBox_precipitation_height_unit";
            this.comboBox_precipitation_height_unit.Size = new System.Drawing.Size(96, 21);
            this.comboBox_precipitation_height_unit.TabIndex = 31;
            // 
            // label_length_unit
            // 
            this.label_length_unit.Location = new System.Drawing.Point(160, 56);
            this.label_length_unit.Name = "label_length_unit";
            this.label_length_unit.Size = new System.Drawing.Size(104, 16);
            this.label_length_unit.TabIndex = 30;
            this.label_length_unit.Text = "Length";
            // 
            // label_precipitation_height_unit
            // 
            this.label_precipitation_height_unit.Location = new System.Drawing.Point(16, 96);
            this.label_precipitation_height_unit.Name = "label_precipitation_height_unit";
            this.label_precipitation_height_unit.Size = new System.Drawing.Size(144, 16);
            this.label_precipitation_height_unit.TabIndex = 29;
            this.label_precipitation_height_unit.Text = "Precipitation Height";
            // 
            // comboBox_pressure_unit
            // 
            this.comboBox_pressure_unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_pressure_unit.ItemHeight = 13;
            this.comboBox_pressure_unit.Items.AddRange(new object[] {
                                                                        "INHG",
                                                                        "MMHG",
                                                                        "HPA",
                                                                        "ATM"});
            this.comboBox_pressure_unit.Location = new System.Drawing.Point(16, 72);
            this.comboBox_pressure_unit.Name = "comboBox_pressure_unit";
            this.comboBox_pressure_unit.Size = new System.Drawing.Size(96, 21);
            this.comboBox_pressure_unit.TabIndex = 28;
            // 
            // label_pressure_unit
            // 
            this.label_pressure_unit.Location = new System.Drawing.Point(16, 56);
            this.label_pressure_unit.Name = "label_pressure_unit";
            this.label_pressure_unit.Size = new System.Drawing.Size(96, 16);
            this.label_pressure_unit.TabIndex = 27;
            this.label_pressure_unit.Text = "Pressure";
            // 
            // comboBox_wind_unit
            // 
            this.comboBox_wind_unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_wind_unit.ItemHeight = 13;
            this.comboBox_wind_unit.Items.AddRange(new object[] {
                                                                    "Meter/Second",
                                                                    "KiloMeter/Hour",
                                                                    "Miles/Hour",
                                                                    "Knots",
                                                                    "Beaufort"});
            this.comboBox_wind_unit.Location = new System.Drawing.Point(160, 32);
            this.comboBox_wind_unit.Name = "comboBox_wind_unit";
            this.comboBox_wind_unit.Size = new System.Drawing.Size(96, 21);
            this.comboBox_wind_unit.TabIndex = 26;
            // 
            // comboBox_temp_unit
            // 
            this.comboBox_temp_unit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_temp_unit.ItemHeight = 13;
            this.comboBox_temp_unit.Items.AddRange(new object[] {
                                                                    "Fahrenheit",
                                                                    "Celcius"});
            this.comboBox_temp_unit.Location = new System.Drawing.Point(16, 32);
            this.comboBox_temp_unit.Name = "comboBox_temp_unit";
            this.comboBox_temp_unit.Size = new System.Drawing.Size(96, 21);
            this.comboBox_temp_unit.TabIndex = 25;
            // 
            // label_temp_unit
            // 
            this.label_temp_unit.Location = new System.Drawing.Point(16, 16);
            this.label_temp_unit.Name = "label_temp_unit";
            this.label_temp_unit.Size = new System.Drawing.Size(96, 16);
            this.label_temp_unit.TabIndex = 24;
            this.label_temp_unit.Text = "Temperature";
            // 
            // label_wind_unit
            // 
            this.label_wind_unit.Location = new System.Drawing.Point(160, 16);
            this.label_wind_unit.Name = "label_wind_unit";
            this.label_wind_unit.Size = new System.Drawing.Size(104, 16);
            this.label_wind_unit.TabIndex = 23;
            this.label_wind_unit.Text = "Wind Speed";
            // 
            // groupBox_language
            // 
            this.groupBox_language.Controls.Add(this.comboBox_language);
            this.groupBox_language.Location = new System.Drawing.Point(8, 192);
            this.groupBox_language.Name = "groupBox_language";
            this.groupBox_language.Size = new System.Drawing.Size(120, 40);
            this.groupBox_language.TabIndex = 24;
            this.groupBox_language.TabStop = false;
            this.groupBox_language.Text = "Language";
            // 
            // comboBox_language
            // 
            this.comboBox_language.Location = new System.Drawing.Point(8, 16);
            this.comboBox_language.Name = "comboBox_language";
            this.comboBox_language.Size = new System.Drawing.Size(104, 21);
            this.comboBox_language.TabIndex = 0;
            // 
            // FormMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(290, 416);
            this.Controls.Add(this.groupBox_language);
            this.Controls.Add(this.groupBox_units);
            this.Controls.Add(this.groupBox_current_state);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.label_city);
            this.Controls.Add(this.comboBox_cities);
            this.Controls.Add(this.groupBox_Window);
            this.Controls.Add(this.groupBox_notifyicon);
            this.Controls.Add(this.button_apply);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMain";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Options";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.Closing += new System.ComponentModel.CancelEventHandler(this.FormMain_Closing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.Activated += new System.EventHandler(this.FormMain_Activated);
            this.groupBox_notifyicon.ResumeLayout(false);
            this.groupBox_Window.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_w_opacity)).EndInit();
            this.groupBox_current_state.ResumeLayout(false);
            this.groupBox_units.ResumeLayout(false);
            this.groupBox_language.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        public void set_frm_weatherview_options_position(int x,int y)
        {
            this.obj_options.window_pos_x=x;
            this.obj_options.window_pos_y=y;
            this.obj_options.save(this.exe_path+CONFIG_FILENAME);
        }

        private void show_ordered_notify_icons(int[] visible_item_number)
        {
            int cnt;
            // the left pos one should be put in last position
            // hide already visibled icons to show them again in a view to respect icon order
            for (cnt=notify_icon_number-1;cnt>-1;cnt--)
                this.array_NotifyIcon[cnt].Visible=false;

            // show visible item
            int cnt2;
            if (visible_item_number==null)
                return;
            if (visible_item_number.Length==0)
                return;
            for (cnt=notify_icon_number-1;cnt>-1;cnt--)
            {
                for (cnt2=visible_item_number.Length-1;cnt2>-1;cnt2--)
                {
                    if (visible_item_number[cnt2]==cnt)
                    {
                        this.array_NotifyIcon[cnt].Visible=true;
                        break;
                    }
                }
            }
        }


        #region drawstring_in_notify_icon
        private void drawstring_in_notify_icon(string text,NotifyIcon notify_icon)
        {
            // Create a graphics instance that draws to a bitmap
            Bitmap bitmap = new Bitmap( 16, 16,System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            Graphics graphics = Graphics.FromImage(bitmap);

            // FONT
            System.Drawing.Font drawFont = new System.Drawing.Font("Arial Narrow",8,System.Drawing.FontStyle.Regular);

            // TEXT
            string drawString = text;

            SizeF drawStringSize = new SizeF();
            //Measure the Copyright string in this Font
            drawStringSize = graphics.MeasureString(drawString, drawFont);

            // BRUSH
            System.Drawing.SolidBrush drawBrush = new System.Drawing.SolidBrush(Color.FromArgb( 255, 255, 255, 255));
            // center text in icon image
            graphics.DrawString(drawString, drawFont, drawBrush, 16/2-drawStringSize.Width/2,16/2-drawStringSize.Height/2);

            notify_icon.Icon=System.Drawing.Icon.FromHandle(bitmap.GetHicon());

            drawFont.Dispose();
            drawBrush.Dispose();
            graphics.Dispose();
        }
        #endregion

        public delegate void obj_metar_download_event_MetarDownload_Arrival_thread_Handler(ClassMetarDownload sender, EventArgs_StringData e);
        private void obj_metar_download_event_MetarDownload_Arrival(ClassMetarDownload sender, EventArgs_StringData e)
        {
            this.Invoke(new obj_metar_download_event_MetarDownload_Arrival_thread_Handler(obj_metar_download_event_MetarDownload_Arrival_thread_safe), new Object[] {sender,e});
        }
        public delegate void obj_metar_download_event_MetarDownload_Error_thread_Handler(ClassMetarDownload sender, EventArgs_Exception e);
        private void obj_metar_download_event_MetarDownload_Error(ClassMetarDownload sender, EventArgs_Exception e)
        {
            this.Invoke(new obj_metar_download_event_MetarDownload_Error_thread_Handler(obj_metar_download_event_MetarDownload_Error_thread_safe), new Object[] {sender,e});
        }
        private void obj_metar_download_event_MetarDownload_Arrival_thread_safe(ClassMetarDownload sender, EventArgs_StringData e)
        {
            this.update_information(e.data);
        }

        private void obj_metar_download_event_MetarDownload_Error_thread_safe(ClassMetarDownload sender, EventArgs_Exception e)
        {
            MessageBox.Show(e.exception.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            // show no data imgs (by default obj_metar.clouds,obj_metar.wind and obj_metar.temperature return no data imgs)
            this.update_information("");
            /////////////////////////////////////////////////
            // for debug only if no internet connection
            /////////////////////////////////////////////////
            // string raw_metar="2004/11/28 10:00\r\nTFFR 061800Z 06010KT 010V090 9999 BKN026 28/20 Q1014 TEMPO 6000 SHRA\r\n";
            // this.update_information(raw_metar);
            /////////////////////////////////////////////////
        }

        #region update_information
        private void update_information(string str_metar)
        {
            bool b_empty=(str_metar=="");
            this.last_raw_metar=str_metar;
            ClassMetar obj_metar=new ClassMetar();
            obj_metar.decode_metar(str_metar);
            string str_img_clouds=obj_metar.clouds_array[0].get_sky_image(obj_metar.str_metar);
            string str_img_wind=obj_metar.wind.get_winddir_image();
            string str_img_temp_term=obj_metar.temperature.get_temp_image();
            // switch options.temperature
            string str_temp="";
            string str_temp_unit="";
            string str="";
            if (obj_metar.temperature.current.is_set())
            {
                str=obj_metar.temperature.current.get_string((ClassTemperature.UNITS)this.obj_options.temp_unit,false);
                str_temp=str.Substring(0,str.Length-1);
                str_temp_unit=str.Substring(str.Length-1);
            }

            // switch options.wind_speed
            string str_wind_speed="";
            string str_wind_unit="";
            if (!obj_metar.wind.b_no_data)
            {
                switch(this.obj_options.wind_unit)
                {
                    case ClassOptions.WIND_UNITS.BEAUFORT:
                        str_wind_speed=obj_metar.wind.speed.Beaufort.ToString("0");
                        str_wind_unit="B";
                        break;
                    case ClassOptions.WIND_UNITS.MS:
                        str_wind_speed=Math.Round(obj_metar.wind.speed.Ms,1).ToString(".0");
                        str_wind_unit="Ms";
                        break;
                    case ClassOptions.WIND_UNITS.MH:
                        str_wind_speed=Math.Round(obj_metar.wind.speed.Mileshours,1).ToString(".0");
                        str_wind_unit="Mh";
                        break;
                    case ClassOptions.WIND_UNITS.KNOTS:
                        str_wind_speed=Math.Round(obj_metar.wind.speed.Knots,1).ToString(".0");
                        str_wind_unit="K";
                        break;
                    case ClassOptions.WIND_UNITS.KMH:
                        str_wind_speed=Math.Round(obj_metar.wind.speed.Kmh,0).ToString("0");
                        str_wind_unit="Kmh";
                        break;
                }
            }
            int pos=str_wind_speed.IndexOf(".");
            if ((str_wind_speed.Length>4)&&(pos>0))
                str_wind_speed=str_wind_speed.Substring(0,pos-1);
            // switch pressure unit
            string str_pressure="";
            if (!obj_metar.pressure.b_no_data)
            {
                switch(this.obj_options.pressure_unit)
                {
                    case ClassOptions.PRESSURE_UNITS.ATM:
                        str_pressure=Math.Round(obj_metar.pressure.Atm,0).ToString("0")+" Atm";
                        break;
                    case ClassOptions.PRESSURE_UNITS.HPA:
                        str_pressure=Math.Round(obj_metar.pressure.Hpa,0).ToString("0")+" HPa";
                        break;
                    case ClassOptions.PRESSURE_UNITS.INHG:
                        str_pressure=Math.Round(obj_metar.pressure.Inhg,2).ToString("0.00")+" Ingh";
                        break;
                    case ClassOptions.PRESSURE_UNITS.MMHG:
                        str_pressure=Math.Round(obj_metar.pressure.Mmhg,0).ToString("0")+" Mmhg";
                        break;
                }
            }

            // Update form weather view
            // weather
            this.frm_weather_view.set_img_weather(this.exe_path+IMG_DIRECTORY+str_img_clouds);
            // temp
            this.frm_weather_view.set_temp(str_temp+str_temp_unit);
            this.frm_weather_view.set_img_temp(IMG_DIRECTORY+str_img_temp_term);
            // wind
            this.frm_weather_view.set_wind(str_wind_speed+" "+str_wind_unit);
            this.frm_weather_view.set_img_wind(this.exe_path+IMG_DIRECTORY+str_img_wind);
            // city
            if (this.obj_options.city.country!="")
                this.frm_weather_view.set_city(this.obj_options.city.name+" ("+this.obj_options.city.country+")");
            else
                this.frm_weather_view.set_city(this.obj_options.city.name);
            // pressure
            this.frm_weather_view.set_pressure(str_pressure);

            this.set_notify_icon_text();

            if (str_img_wind!="")
                // tips : str_img_wind contains the direction of wind so use it ;)
                array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_IMG].Text=this.obj_interface_language.wind_direction+" ("+str_img_wind.Substring(0,str_img_wind.Length-4)+")";
            else
                array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_IMG].Text=this.obj_interface_language.wind_direction;

            array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_DATA].Visible=this.obj_options.show_wind_speed_in_satusbar;
            array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_IMG].Visible=this.obj_options.show_wind_dir_in_satusbar;
            array_NotifyIcon[(int)NOTIFY_ICON_POS.TEMP].Visible=this.obj_options.show_temp_in_satusbar;
            array_NotifyIcon[(int)NOTIFY_ICON_POS.WEATHER].Visible=this.obj_options.show_clouds_in_satusbar;
            // update notify icons (must be reverse from the wanted position in case of already visible with no image)
            this.drawstring_in_notify_icon(str_wind_speed,this.array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_DATA]);
            if (str_img_wind!="")
                array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_IMG].Icon=System.Drawing.Icon.FromHandle(
                    this.GetThumb(new Bitmap(this.exe_path+IMG_DIRECTORY+str_img_wind),16,16).GetHicon());
            // remove � if str_temp is too long
            if (str_temp.Length>3)
                str_temp=str_temp.Substring(0,3);
            this.drawstring_in_notify_icon(str_temp,this.array_NotifyIcon[(int)NOTIFY_ICON_POS.TEMP]);
            // if imgs are 80*50 crop them to 50*50 to avoid distortion

            if (str_img_clouds!="")
                array_NotifyIcon[(int)NOTIFY_ICON_POS.WEATHER].Icon=System.Drawing.Icon.FromHandle(
                    this.GetThumb(this.bitmap_crop(new Bitmap(this.exe_path+IMG_DIRECTORY+str_img_clouds),15,0,50,50),16,16).GetHicon());


            if ((this.frm_weather_view.ShoudBeShow))
            {
                this.frm_weather_view.panel_wind.Visible=this.obj_options.show_wind_in_window;
                this.frm_weather_view.panel_pressure.Visible=this.obj_options.show_pressure_in_window;
                this.frm_weather_view.panel_weather.Visible=this.obj_options.show_clouds_in_window;
                this.frm_weather_view.panel_temp.Visible=this.obj_options.show_temp_in_window;
                this.frm_weather_view.Show();
                this.frm_weather_view.modify_display(this.obj_options.top_most,this.obj_options.opacity,this.obj_options.ColumnsPanelNumber);
            }

            // update details
            if (b_empty)
                this.frm_details.set_metar(null,this.obj_options);
            else
                this.frm_details.set_metar(obj_metar,this.obj_options);

        }
        public bool ThumbnailCallback()
        {
            return false;
        }
        public Bitmap GetThumb(Bitmap bmp,int width,int height)
        {
            Image.GetThumbnailImageAbort myCallback = new Image.GetThumbnailImageAbort(ThumbnailCallback);
            return (Bitmap)bmp.GetThumbnailImage(width, height, myCallback, IntPtr.Zero);
        }
        private Bitmap bitmap_crop(Bitmap b, int x_origin, int y_origin, int width, int height)
        {
            if ((x_origin+width>b.Width) || ( y_origin+height>b.Height) || (x_origin<0)|| (y_origin<0)|| (width<0)|| (height<0))
                throw new Exception("Invalid parameters");
            return b.Clone(new Rectangle(x_origin,y_origin,width,height),System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        }
        #endregion

        #region notify icons menu items
        private void menuItem_exit_Click(object sender, System.EventArgs e)
        {
            this.frm_weather_view.CloseForced();
            this.CloseForced();
        }

        private void menuItem_about_Click(object sender, System.EventArgs e)
        {
            FormAbout frm_about=new FormAbout();
            frm_about.Text=this.obj_interface_language.about;
            frm_about.Show();
        }

        private void menuItem_details_Click(object sender, System.EventArgs e)
        {
            this.frm_details.Show();
        }

        private void menuItem_options_Click(object sender, System.EventArgs e)
        {
            this.show_me();
        }

        private void menuItem_hide_show_Click(object sender, System.EventArgs e)
        {
            if (this.frm_weather_view.Visible)
                this.frm_weather_view.Hide();
            else
                this.frm_weather_view.Show();
        }

        private void NotifyIcon_DoubleClick(object sender, EventArgs e)
        {
            this.menuItem_hide_show_Click(sender,e);
        }
        #endregion

        #region save options

        private bool save_options()
        {
            string[] str_array=this.comboBox_cities.Text.Split(':');
            string city_name="";
            string country="";
            if (str_array.Length==2)
            {
                city_name=str_array[1].Trim();
                country=str_array[0].Trim();
            }
            this.obj_options.city=ClassCity.get_city_from_city_name_and_country(ref this.pcity_list,city_name,country);
            // if city code not found
            if (this.obj_options.city==null)
            {
                MessageBox.Show(this,"City not found in database","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                this.show_me();
                return false;
            }

            this.obj_options.window_orientation=(ClassOptions.WINDOW_ORIENTATION)this.comboBox_orientation.SelectedIndex;
            this.obj_options.temp_unit=(ClassOptions.TEMP_UNITS)comboBox_temp_unit.SelectedIndex;
            this.obj_options.wind_unit=(ClassOptions.WIND_UNITS)this.comboBox_wind_unit.SelectedIndex;
            this.obj_options.pressure_unit=(ClassOptions.PRESSURE_UNITS)this.comboBox_pressure_unit.SelectedIndex;
            this.obj_options.length_unit=(ClassOptions.LENGTH_UNITS)this.comboBox_length_unit.SelectedIndex;
            this.obj_options.precipitation_height_unit=(ClassOptions.HEIGTH_UNITS)this.comboBox_precipitation_height_unit.SelectedIndex;
            this.obj_options.height_unit=(ClassOptions.LENGTH_UNITS)this.comboBox_height_unit.SelectedIndex;
            this.obj_options.show_clouds_in_satusbar=this.checkBox_clouds.Checked;
            this.obj_options.show_temp_in_satusbar=this.checkBox_temp.Checked;
            this.obj_options.show_wind_dir_in_satusbar=this.checkBox_wind_dir.Checked;
            this.obj_options.show_wind_speed_in_satusbar=this.checkBox_wind_speed.Checked;
            this.obj_options.show_clouds_in_window=this.checkBox_w_clouds.Checked;
            this.obj_options.show_temp_in_window=this.checkBox_w_temp.Checked;
            this.obj_options.show_wind_in_window=this.checkBox_w_wind.Checked;
            this.obj_options.show_pressure_in_window=this.checkBox_w_pressure.Checked;
            this.obj_options.top_most=this.checkBox_w_topmost.Checked;
            this.obj_options.opacity=((double)this.trackBar_w_opacity.Value)/100;
            this.obj_options.report_language=this.comboBox_language.Text;
            this.frm_details.set_language(this.exe_path+LANGUAGE_DIRECTORY+this.obj_options.report_language+".xml");

            this.set_notify_icon_text();

            this.obj_options.save(this.exe_path+CONFIG_FILENAME);

            return true;
        }

        #endregion

        private void set_notify_icon_text()
        {
            string str_wind_unit="";
            switch(this.obj_options.wind_unit)
            {
                case ClassOptions.WIND_UNITS.BEAUFORT:
                    str_wind_unit="B";
                    break;
                case ClassOptions.WIND_UNITS.MS:
                    str_wind_unit="Ms";
                    break;
                case ClassOptions.WIND_UNITS.MH:
                    str_wind_unit="Mh";
                    break;
                case ClassOptions.WIND_UNITS.KNOTS:
                    str_wind_unit="K";
                    break;
                case ClassOptions.WIND_UNITS.KMH:
                    str_wind_unit="Kmh";
                    break;
            }

            string str_temp_unit="";
            switch(this.obj_options.temp_unit)
            {
                case ClassOptions.TEMP_UNITS.CELCIUS:
                    str_temp_unit="C";
                    break;
                case ClassOptions.TEMP_UNITS.FAHRENHEIT:
                    str_temp_unit="F";
                    break;
            }

            this.array_NotifyIcon[(int)NOTIFY_ICON_POS.WEATHER].Text =this.obj_interface_language.weather;
            this.array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_IMG].Text = this.obj_interface_language.wind_direction;
            this.array_NotifyIcon[(int)NOTIFY_ICON_POS.TEMP].Text = this.obj_interface_language.temperature+" ("+str_temp_unit+")";
            this.array_NotifyIcon[(int)NOTIFY_ICON_POS.WIND_DATA].Text = this.obj_interface_language.wind_speed+" ("+str_wind_unit+")";
        }
        public void show_me()
        {
            this.ShowInTaskbar=true;
            this.WindowState=FormWindowState.Normal;
            this.Show();
            this.Activate();
        }

        public void start()
        {
            if (this.obj_options.city.code!="")
                this.start_from_config();
            else
                this.show_me();
        }

        private void start_from_config()
        {
           this.obj_metar_download.start(this.obj_options.city.code,this.obj_options.update_interval,this.obj_options.retry_interval,this.obj_options.host,this.obj_options.remote_dir);

           #region notify icon showing
            int[] array =new int[this.notify_icon_number];
            for (int cnt=0;cnt<this.notify_icon_number;cnt++)
                array[cnt]=-1;
            int nb_visible_icon=0;
            if (this.obj_options.show_clouds_in_satusbar)
            {
                array[(int)NOTIFY_ICON_POS.WEATHER]=(int)NOTIFY_ICON_POS.WEATHER;
                nb_visible_icon++;
            }
            if (this.obj_options.show_temp_in_satusbar)
            {
                array[(int)NOTIFY_ICON_POS.TEMP]=(int)NOTIFY_ICON_POS.TEMP;
                nb_visible_icon++;
            }
            if (this.obj_options.show_wind_dir_in_satusbar)
            {
                array[(int)NOTIFY_ICON_POS.WIND_IMG]=(int)NOTIFY_ICON_POS.WIND_IMG;
                nb_visible_icon++;
            }
            if (this.obj_options.show_wind_speed_in_satusbar)
            {
                array[(int)NOTIFY_ICON_POS.WIND_DATA]=(int)NOTIFY_ICON_POS.WIND_DATA;
                nb_visible_icon++;
            }
            if (nb_visible_icon>0)
            {
                int[] array_visible=new int[nb_visible_icon];
                int cnt2=0;
                for (int cnt=0;cnt<this.notify_icon_number;cnt++)
                {
                    if (array[cnt]!=-1)
                    {
                        array_visible[cnt2]=array[cnt];
                        cnt2++;
                    }
                }
                // show wanted notify icons only
                this.show_ordered_notify_icons(array_visible);
            }
            #endregion

        }

        #region form events

        public bool hide_query()
        {
            return this.hide_query(false);
        }
        public bool hide_query(bool check_only)
        {
            // if this is the only shown form close it
            bool b_no_icon=!(this.obj_options.show_clouds_in_satusbar||this.obj_options.show_temp_in_satusbar
                ||this.obj_options.show_wind_dir_in_satusbar||this.obj_options.show_wind_speed_in_satusbar
                );
            if ((!this.frm_weather_view.ShoudBeShow)&&b_no_icon)
                return false;
            b_no_icon=true;
            for (int cnt=0;cnt<this.notify_icon_number;cnt++)
            {
                if ((this.array_NotifyIcon[cnt].Visible==true)&&(this.array_NotifyIcon[cnt].Icon!=null))
                {
                    b_no_icon=false;
                    break;
                }
            }
//            if (b_no_icon&&(!this.obj_metar_download.Started)&&(!this.frm_weather_view.Visible))
            if (b_no_icon&&!this.frm_weather_view.Visible)
                return false;

            if (!check_only)
                this.Hide();
            return true;
        }

        public void CloseForced()
        {
            this.b_closed_forced=true;
            this.Close();
        }
        private void FormMain_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (this.b_closed_forced)
            {
                this.obj_metar_download.stop();
                return;
            }
            this.hide_query();
            // else hide
            e.Cancel=true;
        }

        private void button_exit_Click(object sender, System.EventArgs e)
        {
            this.CloseForced();
        }
        private void button_cancel_Click(object sender, System.EventArgs e)
        {
            this.hide_query();
        }

        private void button_apply_Click(object sender, System.EventArgs e)
        {
            if (this.save_options())
            {
                this.update_language_interface();
                // update visual information
                this.update_information(this.last_raw_metar);
                this.start_from_config();
            }
            this.hide_query();       
        }

        private void show_state()
        {
            // update current state
            if (this.obj_metar_download.Started)
            {
                this.label_current_state.Text=this.obj_interface_language.started+"\r\n"
                    +this.obj_interface_language.city+": "
                    +this.obj_options.city.name;
            }
            else
            {
                this.label_current_state.Text=this.obj_interface_language.stopped;
            }
        }
        private void FormMain_Activated(object sender, System.EventArgs e)
        {
            this.show_state();
        }

        private void FormMain_Load(object sender, System.EventArgs e)
        {
            this.start();
        }

        #endregion

        private void update_language_interface()
        {
            this.obj_interface_language=ClassInterfaceLanguage.load(this.exe_path+LANGUAGE_INTERFACE_DIRECTORY+this.obj_options.report_language+".xml");

            this.Text=this.obj_interface_language.options;

            this.groupBox_current_state.Text=this.obj_interface_language.current_state;
            this.groupBox_language.Text=this.obj_interface_language.language;
            this.groupBox_units.Text=this.obj_interface_language.units;
            this.groupBox_Window.Text=this.obj_interface_language.window;

            this.checkBox_clouds.Text=this.obj_interface_language.weather;
            this.checkBox_temp.Text=this.obj_interface_language.temperature;
            this.checkBox_w_clouds.Text=this.obj_interface_language.weather;
            this.checkBox_w_pressure.Text=this.obj_interface_language.pressure;
            this.checkBox_w_temp.Text=this.obj_interface_language.temperature;
            this.checkBox_w_topmost.Text=this.obj_interface_language.top_most_window;
            this.checkBox_w_wind.Text=this.obj_interface_language.wind;
            this.checkBox_wind_dir.Text=this.obj_interface_language.wind_direction;
            this.checkBox_wind_speed.Text=this.obj_interface_language.wind_speed;

            this.label_city.Text=this.obj_interface_language.country_city;
            this.label_height_unit.Text=this.obj_interface_language.height;
            this.label_length_unit.Text=this.obj_interface_language.length;
            this.label_orientation.Text=this.obj_interface_language.orientation;
            this.label_precipitation_height_unit.Text=this.obj_interface_language.precipitation_height;
            this.label_pressure_unit.Text=this.obj_interface_language.pressure;
            this.label_temp_unit.Text=this.obj_interface_language.temperature;
            this.label_wind_unit.Text=this.obj_interface_language.wind;
            this.label_window_opacity.Text=this.obj_interface_language.window_opacity;

            this.button_apply.Text=this.obj_interface_language.apply;
            this.button_cancel.Text=this.obj_interface_language.cancel;
            this.button_exit.Text=this.obj_interface_language.exit;

            this.menuItem_about.Text=this.obj_interface_language.about;
            this.menuItem_details.Text=this.obj_interface_language.details;
            this.menuItem_exit.Text=this.obj_interface_language.exit;
            this.menuItem_hide_show.Text=this.obj_interface_language.show_hide;
            this.menuItem_options.Text=this.obj_interface_language.options;

            this.show_state();

            this.frm_details.Text=this.obj_interface_language.details;

            this.frm_weather_view.set_tooltips_text(this.obj_interface_language.details,this.obj_interface_language.options);

        }

    }

}
