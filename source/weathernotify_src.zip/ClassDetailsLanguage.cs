/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for ClassDetailsLanguage.
	/// </summary>
	public class ClassDetailsLanguage
	{
        public string no_data                    = "Sorry ! There's no data available for {0}.";
        public string list_sentences_and         = " and ";
        public string list_sentences_comma       = ", ";
        public string list_sentences_final_and   = ", and ";
        public string location                   = "This is a report for {0}.";
        public string minutes                    = " minutes";
        public string time_format                = " The report was made {0} ago, at {1:t} UTC.";
        public string time_minutes               = "and {0} minutes";
        public string time_one_hour              = "one hour {0}";
        public string time_several_hours         = "{0} hours {1}";
        public string time_a_moment              = "a moment";
        public string time_one_day               = "one day";
        public string time_several_days          = "{0} days";
        public string meters_per_second          = " meters per second";
        public string miles_per_hour             = " miles per hour";
        public string kilometers_per_hour        = " kilometers per hour";
        public string knots                      = " knots";
        public string beaufort                   = " beaufort";
        public string meter                      = " meter";
        public string meters                     = " meters";
        public string feet                       = " feet";
        public string kilometers                 = " kilometers";
        public string miles                      = " miles";
        public string inches                     = " inches";
        public string millimeters                = " millimeters";
        
        public string and                        = " and ";
        public string plus                       = " plus ";
        public string with                       = " with ";
        public string wind_blowing               = " The wind was blowing at a speed of ";
        public string wind_with_gusts            = " with gusts up to ";
        public string wind_from                  = " from ";
        public string wind_variable              = " from variable directions.";
        public string wind_varying               = ", varying between {0} ({1}�) and {2} ({3}�)";
        public string wind_calm                  = " The wind was calm";

        public string temperature       = " The temperature was ";
        public string temp_min_max_6_hours =" The temperature was between {0} and {1} in the last 6 hours";
        public string temp_min_6_hours =" The minimum temperature in the last 6 hours was {0}.";
        public string temp_max_6_hours =" The maximum temperature in the last 6 hours was {0}.";
        public string temp_min_max_24_hours =" The temperature was between {0} and {1} in the last 24 hours";
        public string temp_min_24_hours =" The minimum temperature in the last 24 hours was {0}.";
        public string temp_max_24_hours =" The maximum temperature in the last 24 hours was {0}.";        
            
        public string dew_point         = ", with a dew-point at ";
        public string altimeter         = " The atmospheric pressure was ";
        public string hPa               = " hPa";
        public string inHg              = " inHg";
        public string Atm               = " Atm";
        public string mmHg              = " mmHg";

        public string rel_humidity      = " The relative humidity was ";
        public string feelslike         = " The temperature felt like ";
        public string cloud_group_beg   = " There were ";
        public string cloud_group_end   = ".";
        public string cloud_clear       = " The sky was clear.";
        public string cloud_height      = " clouds at a height of ";
        public string cloud_overcast    = " The sky was overcast from a height of ";
        public string cloud_vertical_visibility   = "a vertical visibility of ";

        public string cumulonimbus       = " cumulonimbus";
        public string towering_cumulus   = " towering cumulus";
        public string cavok              = " no clouds below {0} and no cumulonimbus clouds";
        public string currently          = " Currently ";

        public string visibility         = " The overall visibility was ";
        public string visibility_greater_than    = "greater than ";
        public string visibility_less_than       = "less than ";
        public string visibility_to              = " to the ";
        public string runway_upward_tendency     = " with an upward tendency";
        public string runway_downward_tendency   = " with a downward tendency";
        public string runway_no_tendency         = " with no distinct tendency";
        public string runway_between             = "between ";
        public string runway_left                = " left";
        public string runway_central             = " central";
        public string runway_right               = " right";
        public string runway_visibility          = " The visibility was ";
        public string runway_for_runway          = " for runway ";

        public string precip_a_trace             = "a trace";
        public string precip_last_hour           = " in last hour";
        public string precip_last_6_hours        = " in last 6 hours";
        public string precip_last_24_hours       = " in last 24 hours";
        public string precip_snow                = " of snow";
        public string precip_there_was           = " Precipitation was ";
        

    
    
        
        
        // special case for array as hash table can't be serialize

        public string[] wind_dir   ={
                                        "north",
                                        "north/northeast",
                                        "northeast",
                                        "east/northeast",
                                        "east",
                                        "east/southeast",
                                        "southeast",
                                        "south/southeast",
                                        "south",
                                        "south/southwest",
                                        "southwest",
                                        "west/southwest",
                                        "west",
                                        "west/northwest",
                                        "northwest",
                                        "north/northwest",
                                        "north"};
        public string[] wind_dir_short   = {
                                               "N",
                                               "NNE",
                                               "NE",
                                               "ENE",
                                               "E",
                                               "ESE",
                                               "SE",
                                               "SSE",
                                               "S",
                                               "SSW",
                                               "SW",
                                               "WSW",
                                               "W",
                                               "WNW",
                                               "NW",
                                               "NNW",
                                               "N"};


        // respect the ClassClouds.Coverage enum CLR,FEW,SCT,BKN,OVC,SKC, (CAVOK,VV not used [particular conditions])
        public string[] cloud_condition = {"clear", "a few","scattered","broken","overcast","clear"};


        public Class_StrHash[] weather = {
                                    new Class_StrHash("-" , " light"),
                                    new Class_StrHash(" " , " moderate "),
                                    new Class_StrHash("+" , " heavy "),
                                    new Class_StrHash("VC" , " in the vicinity"),
                                    new Class_StrHash("PR" , " partial"),
                                    new Class_StrHash("BC" , " patches of"),
                                    new Class_StrHash("MI" , " shallow"),
                                    new Class_StrHash("DR" , " low drifting"),
                                    new Class_StrHash("BL" , " blowing"),
                                    new Class_StrHash("SH" , " showers of"),
                                    new Class_StrHash("TS" , " thunderstorm"),
                                    new Class_StrHash("FZ" , " freezing"),
                                    new Class_StrHash("DZ" , " drizzle"),
                                    new Class_StrHash("RA" , " rain"),
                                    new Class_StrHash("SN" , " snow"),
                                    new Class_StrHash("SG" , " snow grains"),
                                    new Class_StrHash("IC" , " ice crystals"),
                                    new Class_StrHash("PL" , " ice pellets"),
                                    new Class_StrHash("GR" , " hail"),
                                    new Class_StrHash("GS" , " small hail"),
                                    new Class_StrHash("UP" , " unknown"),
                                    new Class_StrHash("BR" , " mist"),
                                    new Class_StrHash("FG" , " fog"),
                                    new Class_StrHash("FU" , " smoke"),
                                    new Class_StrHash("VA" , " volcanic ash"),
                                    new Class_StrHash("DU" , " widespread dust"),
                                    new Class_StrHash("SA" , " sand"),
                                    new Class_StrHash("HZ" , " haze"),
                                    new Class_StrHash("PY" , " spray"),
                                    new Class_StrHash("PO" , " well-developed dust/sand whirls"),
                                    new Class_StrHash("SQ" , " squalls"),
                                    new Class_StrHash("FC" , " funnel cloud tornado waterspout"),
                                    new Class_StrHash("SS" , " sandstorm/duststorm")
                                    };

        public Class_StrHash[] wind_dir_short_long =
                                                {
                                                    new Class_StrHash("N"  , "north"),
                                                    new Class_StrHash("NE" , "northeast"),
                                                    new Class_StrHash("E"  , "east"),
                                                    new Class_StrHash("SE" , "southeast"),
                                                    new Class_StrHash("S"  , "south"),
                                                    new Class_StrHash("SW" , "southwest"),
                                                    new Class_StrHash("W"  , "west"),
                                                    new Class_StrHash("NW" , "northwest")
                                                };


		public ClassDetailsLanguage()
		{
			//
			// TODO: Add constructor logic here
			//
		}
        public static ClassDetailsLanguage load(string config_file_name)
        {
            try
            {
                if (System.IO.Path.GetFileNameWithoutExtension(config_file_name)=="")// don't show error if application is run for first time 
                    return new ClassDetailsLanguage();
                return (ClassDetailsLanguage)XML_access.XMLDeserializeObject(config_file_name,typeof(ClassDetailsLanguage));
            }
            catch(Exception e)
            {
                System.Windows.Forms.MessageBox.Show("Error loading language file "+config_file_name+".\r\n"+e.Message+"\r\nDefault language will be used","Error",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
                return new ClassDetailsLanguage();
            }
        }
        public bool save(string config_file_name)
        {
            try
            {
                XML_access.XMLSerializeObject(config_file_name,this,typeof(ClassDetailsLanguage));
                return true;
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message,"Error",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
                return false;            
            }
        }
	}
}
