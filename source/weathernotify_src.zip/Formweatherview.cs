/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for FormWeatherView.
	/// </summary>
	public class FormWeatherView : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

        // only for panels positions
        private enum PANEL_POS{POS_PANEL_WEATHER=0,POS_PANEL_TEMP,POS_PANEL_WIND,POS_PANEL_PRESSURE};
        // specify if window has been closed (avoid to show it each time data is updated)
        private bool has_been_closed=false;

        private FormMain form_options;
        private FormDetails form_details;
        public System.Windows.Forms.Panel panel_weather;
        public System.Windows.Forms.Panel panel_temp;
        public System.Windows.Forms.Panel panel_wind;
        private System.Windows.Forms.PictureBox picturebox_weather;
        private System.Windows.Forms.PictureBox picturebox_temp;
        private System.Windows.Forms.PictureBox picturebox_wind;
        private System.Windows.Forms.Label label_wind;
        private System.Windows.Forms.Label label_temp;
        public System.Windows.Forms.Panel panel_pressure;
        private System.Windows.Forms.Label label_pressure;
        private System.Windows.Forms.Panel panel_options;
        private System.Windows.Forms.Button button_options;
        private System.Windows.Forms.Button button_details;
        private ClassOptions obj_options;
        private ToolTip tool_tip;
        
		public FormWeatherView(FormMain form_options, ref ClassOptions options,FormDetails form_details)
		{
            this.obj_options=options;
            this.form_options=form_options;
            this.form_details=form_details;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

            this.tool_tip=new ToolTip();
            this.tool_tip.SetToolTip(this.button_details,"Details");
            this.tool_tip.SetToolTip(this.button_options,"Options");
            this.Top=this.obj_options.window_pos_y;
            this.Left=this.obj_options.window_pos_x;

            // XPStyle.MakeXPStyle(this); if flatstyle=system image are not diplayed
		}

        public void set_tooltips_text(string details,string options)
        {
            this.tool_tip.SetToolTip(this.button_details,details);
            this.tool_tip.SetToolTip(this.button_options,options);
        }
        private Image get_image(string fullpath)
        {
            try
            {
                return Image.FromFile(fullpath);
            }
            catch
            {
                MessageBox.Show( "File "+fullpath+" not found.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return null;
            }
        }
        public void set_img_weather(string fullpath)
        {
            Image img=get_image(fullpath);
            if (img!=null)
                this.picturebox_weather.Image=img;
        }
        public void set_img_temp(string fullpath)
        {
            Image img=get_image(fullpath);
            if (img!=null)
                this.picturebox_temp.Image=img;
        }
        public void set_temp(string temp_value)
        {
            if (temp_value=="")
                temp_value="No data";
            this.label_temp.Text=temp_value;
        }
        public void set_img_wind(string fullpath)
        {
            Image img=get_image(fullpath);
            if (img!=null)
                this.picturebox_wind.Image=img;
        }
        public void set_wind(string wind_value)
        {
            if (wind_value.Trim()=="")
                wind_value="No data";
            this.label_wind.Text=wind_value;
        }
        public void set_city(string city)
        {
            this.Text=city;
        }
        public void set_pressure(string pressure)
        {
            if (pressure.Trim()=="")
                pressure="No data";
            this.label_pressure.Text=pressure;
        }
        /// <summary>
        /// arrange display. Must be called only when form is visible (else panel.Visible is false anyway)
        /// </summary>
        /// <param name="topmost"></param>
        /// <param name="opacity"></param>
        /// <param name="nb_columns_panel"></param>
        public void modify_display(bool topmost,double opacity,int nb_columns_panel)
        {
            this.SuspendLayout();
            // panel position
            int panel_number=5;

            int panel_box_height=50;
            int panel_box_width=80;
            int panel_current_column=0;
            int panel_current_row=0;
            
            Panel[] array_panel=new Panel[panel_number];
            array_panel[(int)PANEL_POS.POS_PANEL_WEATHER]=panel_weather;
            array_panel[(int)PANEL_POS.POS_PANEL_TEMP]=panel_temp;
            array_panel[(int)PANEL_POS.POS_PANEL_WIND]=panel_wind;
            array_panel[(int)PANEL_POS.POS_PANEL_PRESSURE]=panel_pressure;
            array_panel[panel_number-1]=panel_options;

            for (int cnt=0;cnt<array_panel.Length;cnt++)
            {
                if (array_panel[cnt].Visible==false)
                    continue;
                array_panel[cnt].Top=panel_current_row*panel_box_height;
                array_panel[cnt].Left=panel_current_column*panel_box_width;
                
                array_panel[cnt].Height=panel_box_height;
                array_panel[cnt].Width=panel_box_width;
                
                if (panel_current_column<nb_columns_panel-1)
                    panel_current_column++;
                else
                {
                    panel_current_column=0;
                    panel_current_row++;
                }
            }

            // button position in panel_options
            this.button_details.Top=this.panel_options.Height/2-this.button_details.Height/2;
            this.button_details.Left=this.panel_options.Width/4-this.button_details.Width/2;

            this.button_options.Top=this.panel_options.Height/2-this.button_options.Height/2;
            this.button_options.Left=this.panel_options.Width*3/4-this.button_options.Width/2;

            // assume that picture box wind is verticaly centered
            this.picturebox_wind.Width=40;//depending of img size
            this.picturebox_wind.Height=40;//depending of img size
            this.picturebox_wind.Left=0;
            this.picturebox_wind.Top=panel_box_height/2-this.picturebox_wind.Height/2;

            // label wind
            this.label_wind.Width=this.panel_wind.Width-this.picturebox_wind.Width+this.picturebox_wind.Left;
            // label temp
            this.label_temp.Width=this.panel_temp.Width-this.picturebox_temp.Width+this.picturebox_temp.Left;

            // comput size of window
            int new_width;
            int new_height;
            if (panel_current_row==0)
                new_width=panel_current_column*panel_box_width;
            else
                new_width=nb_columns_panel*panel_box_width;
            if (panel_current_column==0)//last row is empty 
                panel_current_row--;
            new_height=(panel_current_row+1)*panel_box_height;
            this.ClientSize=new Size(new_width,new_height);

            // set topmost and opacity
            this.TopMost=topmost;
            this.Opacity=opacity;
            this.ResumeLayout();
        }


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormWeatherView));
            this.panel_weather = new System.Windows.Forms.Panel();
            this.picturebox_weather = new System.Windows.Forms.PictureBox();
            this.panel_pressure = new System.Windows.Forms.Panel();
            this.label_pressure = new System.Windows.Forms.Label();
            this.panel_wind = new System.Windows.Forms.Panel();
            this.label_wind = new System.Windows.Forms.Label();
            this.picturebox_wind = new System.Windows.Forms.PictureBox();
            this.panel_temp = new System.Windows.Forms.Panel();
            this.label_temp = new System.Windows.Forms.Label();
            this.picturebox_temp = new System.Windows.Forms.PictureBox();
            this.panel_options = new System.Windows.Forms.Panel();
            this.button_details = new System.Windows.Forms.Button();
            this.button_options = new System.Windows.Forms.Button();
            this.panel_weather.SuspendLayout();
            this.panel_pressure.SuspendLayout();
            this.panel_wind.SuspendLayout();
            this.panel_temp.SuspendLayout();
            this.panel_options.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_weather
            // 
            this.panel_weather.Controls.Add(this.picturebox_weather);
            this.panel_weather.Location = new System.Drawing.Point(0, 0);
            this.panel_weather.Name = "panel_weather";
            this.panel_weather.Size = new System.Drawing.Size(80, 50);
            this.panel_weather.TabIndex = 0;
            // 
            // picturebox_weather
            // 
            this.picturebox_weather.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picturebox_weather.Location = new System.Drawing.Point(0, 0);
            this.picturebox_weather.Name = "picturebox_weather";
            this.picturebox_weather.Size = new System.Drawing.Size(80, 50);
            this.picturebox_weather.TabIndex = 0;
            this.picturebox_weather.TabStop = false;
            // 
            // panel_pressure
            // 
            this.panel_pressure.Controls.Add(this.label_pressure);
            this.panel_pressure.Location = new System.Drawing.Point(240, 0);
            this.panel_pressure.Name = "panel_pressure";
            this.panel_pressure.Size = new System.Drawing.Size(80, 50);
            this.panel_pressure.TabIndex = 1;
            // 
            // label_pressure
            // 
            this.label_pressure.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_pressure.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.label_pressure.Location = new System.Drawing.Point(0, 0);
            this.label_pressure.Name = "label_pressure";
            this.label_pressure.Size = new System.Drawing.Size(80, 50);
            this.label_pressure.TabIndex = 0;
            this.label_pressure.Text = "Pressure";
            this.label_pressure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_wind
            // 
            this.panel_wind.Controls.Add(this.label_wind);
            this.panel_wind.Controls.Add(this.picturebox_wind);
            this.panel_wind.Location = new System.Drawing.Point(160, 0);
            this.panel_wind.Name = "panel_wind";
            this.panel_wind.Size = new System.Drawing.Size(80, 50);
            this.panel_wind.TabIndex = 2;
            // 
            // label_wind
            // 
            this.label_wind.Dock = System.Windows.Forms.DockStyle.Right;
            this.label_wind.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.label_wind.Location = new System.Drawing.Point(32, 0);
            this.label_wind.Name = "label_wind";
            this.label_wind.Size = new System.Drawing.Size(48, 50);
            this.label_wind.TabIndex = 1;
            this.label_wind.Text = "Wind";
            this.label_wind.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picturebox_wind
            // 
            this.picturebox_wind.Location = new System.Drawing.Point(0, 8);
            this.picturebox_wind.Name = "picturebox_wind";
            this.picturebox_wind.Size = new System.Drawing.Size(50, 50);
            this.picturebox_wind.TabIndex = 0;
            this.picturebox_wind.TabStop = false;
            // 
            // panel_temp
            // 
            this.panel_temp.Controls.Add(this.label_temp);
            this.panel_temp.Controls.Add(this.picturebox_temp);
            this.panel_temp.Location = new System.Drawing.Point(80, 0);
            this.panel_temp.Name = "panel_temp";
            this.panel_temp.Size = new System.Drawing.Size(80, 50);
            this.panel_temp.TabIndex = 3;
            // 
            // label_temp
            // 
            this.label_temp.Dock = System.Windows.Forms.DockStyle.Right;
            this.label_temp.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.label_temp.Location = new System.Drawing.Point(32, 0);
            this.label_temp.Name = "label_temp";
            this.label_temp.Size = new System.Drawing.Size(48, 50);
            this.label_temp.TabIndex = 1;
            this.label_temp.Text = "Temp";
            this.label_temp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picturebox_temp
            // 
            this.picturebox_temp.Location = new System.Drawing.Point(0, 0);
            this.picturebox_temp.Name = "picturebox_temp";
            this.picturebox_temp.Size = new System.Drawing.Size(40, 72);
            this.picturebox_temp.TabIndex = 0;
            this.picturebox_temp.TabStop = false;
            // 
            // panel_options
            // 
            this.panel_options.Controls.Add(this.button_details);
            this.panel_options.Controls.Add(this.button_options);
            this.panel_options.Location = new System.Drawing.Point(320, 0);
            this.panel_options.Name = "panel_options";
            this.panel_options.Size = new System.Drawing.Size(80, 50);
            this.panel_options.TabIndex = 4;
            // 
            // button_details
            // 
            this.button_details.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_details.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button_details.Image = ((System.Drawing.Image)(resources.GetObject("button_details.Image")));
            this.button_details.Location = new System.Drawing.Point(4, 13);
            this.button_details.Name = "button_details";
            this.button_details.Size = new System.Drawing.Size(32, 24);
            this.button_details.TabIndex = 7;
            this.button_details.Tag = "";
            this.button_details.Click += new System.EventHandler(this.button_details_Click);
            // 
            // button_options
            // 
            this.button_options.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_options.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button_options.Image = ((System.Drawing.Image)(resources.GetObject("button_options.Image")));
            this.button_options.Location = new System.Drawing.Point(44, 13);
            this.button_options.Name = "button_options";
            this.button_options.Size = new System.Drawing.Size(32, 24);
            this.button_options.TabIndex = 8;
            this.button_options.Tag = "";
            this.button_options.Click += new System.EventHandler(this.button_options_Click);
            // 
            // FormWeatherView
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(402, 48);
            this.Controls.Add(this.panel_options);
            this.Controls.Add(this.panel_temp);
            this.Controls.Add(this.panel_wind);
            this.Controls.Add(this.panel_pressure);
            this.Controls.Add(this.panel_weather);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormWeatherView";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Retreiving informations Please wait...";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.FormWeatherView_Closing);
            this.panel_weather.ResumeLayout(false);
            this.panel_pressure.ResumeLayout(false);
            this.panel_wind.ResumeLayout(false);
            this.panel_temp.ResumeLayout(false);
            this.panel_options.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

        private bool b_closed_forced=false;
        public void CloseForced()
        {
            this.form_options.set_frm_weatherview_options_position(this.Left,this.Top);
            this.b_closed_forced=true;
            this.Close();
        }

        private void FormWeatherView_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            this.has_been_closed=true;
            if (this.b_closed_forced)
                return;
            // if no more way to view options window
            this.Hide();
            if (!this.form_options.hide_query(true))
            {
                if (MessageBox.Show(this,"Exit Application ?","Information",MessageBoxButtons.YesNo,MessageBoxIcon.Information)
                    ==DialogResult.Yes)
                {
                    // Close
                    this.form_options.CloseForced();
                }
                else
                    this.Show();
            }
            e.Cancel=true;
        }

        private void button_options_Click(object sender, System.EventArgs e)
        {
            this.form_options.show_me();
        }

        private void button_details_Click(object sender, System.EventArgs e)
        {
            this.form_details.Show();
            this.form_details.Activate();
        }
    
        public bool ShoudBeShow
        {
            get
            {
                return (
                        (this.obj_options.show_clouds_in_window
                         ||this.obj_options.show_temp_in_window
                         ||this.obj_options.show_wind_in_window
                         ||this.obj_options.show_pressure_in_window
                        )
                        &&(!this.has_been_closed)// avoid to autoshow form at each update if it has been closed
                       );
            }
        }


	}
}
