/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for ClassClouds.
	/// </summary>
    public class ClassClouds:ClassWeatherInformation
    {
        private const string clouds_nodata_image="clouds_nodata.png";
        public ClassLength length=null;
        public int prefix=0;
        public string cumulus="";
        public string Condition
        {
            get
            {
                return this.condition;
            }
            set
            {
                this.condition=value;
                switch(this.condition)
                {
                    case "CLR":
                        this.coverage=COVERAGE.CLR;
                        break;
                    case "SKC":
                        this.coverage=COVERAGE.SKC;
                        break;
                    case "FEW":
                        this.coverage=COVERAGE.FEW;
                        break;
                    case "SCT":
                        this.coverage=COVERAGE.SCT;
                        break;
                    case "BKN":
                        this.coverage=COVERAGE.BKN;
                        break;
                    case "OVC":
                        this.coverage=COVERAGE.OVC;
                        break;
                    case "VV":
                        this.coverage=COVERAGE.VV;
                        break;
                    case "CAVOK":
                        this.coverage=COVERAGE.CLR;
                        break;
                    default:
                        this.coverage=COVERAGE.CLR;
                        break;
                }
            }
        }
        private string condition="";
        private string phenomena="";

        private INTENSITY intensity=INTENSITY.NORMAL;
        public COVERAGE coverage=COVERAGE.CLR;
        private WEATHER weather=WEATHER.NONE;
        private DAYTIME daytime=DAYTIME.DAY;

        public const double NIL=-1;
        // images[DAYTIME][INTENSITY][WEATHER][COVERAGE]=image_name
        private string[,,,] images=new string[2,3,6,5];

        public enum DAYTIME
        {
            DAY=0,
            NIGHT
        }
        
        public enum COVERAGE
        {
            CLR=0,
            FEW=1,
            SCT=2,
            BKN=3,
            OVC=4,

            SKC,
            CAVOK,
            VV
        }
        public enum WEATHER
        {
            NONE=0,THUN,RAIN,SNOW,HAIL,FOG
        }

        public enum PHENOMENA
        {
            NONE=WEATHER.NONE,
            TS=WEATHER.THUN,
            RA=WEATHER.RAIN,
            DZ=WEATHER.RAIN,
            SN=WEATHER.SNOW,
            SG=WEATHER.SNOW,
            GR=WEATHER.HAIL,
            GS=WEATHER.HAIL,
            PE=WEATHER.HAIL,
            IC=WEATHER.HAIL,
            BR=WEATHER.FOG,
            FG=WEATHER.FOG
        }
        public enum INTENSITY
        {
            LOW=0,NORMAL,HIGHT
        }

		public ClassClouds()
		{
            this.length=new ClassLength();

            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.FEW]="1cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.SCT]="2cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.BKN]="3cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.OVC]="4cloud_norain.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.FEW]="1cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.SCT]="2cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.BKN]="3cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.OVC]="4cloud_norain.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.FEW]="1cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.SCT]="2cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.BKN]="3cloud_norain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.OVC]="4cloud_norain.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.FEW]="1cloud_lightrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.SCT]="2cloud_lightrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.BKN]="3cloud_lightrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.OVC]="4cloud_lightrain.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.FEW]="1cloud_modrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.SCT]="2cloud_modrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.BKN]="3cloud_modrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.OVC]="4cloud_modrain.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.FEW]="1cloud_heavyrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.SCT]="2cloud_heavyrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.BKN]="3cloud_heavyrain.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.OVC]="4cloud_heavyrain.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.FEW]="2cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.SCT]="2cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.BKN]="3cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.OVC]="4cloud_lightsnow.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.FEW]="2cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.SCT]="2cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.BKN]="3cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.OVC]="4cloud_lightsnow.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.FEW]="2cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.SCT]="2cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.BKN]="3cloud_snow.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.OVC]="4cloud_heavysnow.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.FEW]="2cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.SCT]="2cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.BKN]="3cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.OVC]="4cloud_lighthail.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.FEW]="2cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.SCT]="2cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.BKN]="3cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.OVC]="4cloud_lighthail.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.FEW]="2cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.SCT]="2cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.BKN]="3cloud_hail.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.OVC]="4cloud_heavyhail.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.FEW]="2cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.SCT]="2cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.BKN]="3cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.OVC]="4cloud_thunders.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.FEW]="2cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.SCT]="2cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.BKN]="3cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.OVC]="4cloud_thunders.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.CLR]="0cloud.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.FEW]="2cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.SCT]="2cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.BKN]="3cloud_thunders.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.OVC]="4cloud_thunders.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.CLR]="0cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.FEW]="1cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.SCT]="2cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.BKN]="3cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.OVC]="4cloud_fog.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.CLR]="0cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.FEW]="1cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.SCT]="2cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.BKN]="3cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.OVC]="4cloud_fog.png";

            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.CLR]="0cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.FEW]="1cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.SCT]="2cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.BKN]="3cloud_fog.png";
            images[(int)DAYTIME.DAY,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.OVC]="4cloud_fog.png";

            // Night pictures
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.FEW]="n_1cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.SCT]="n_2cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.BKN]="n_3cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.NONE,(int)COVERAGE.OVC]="4cloud_norain.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.FEW]="n_1cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.SCT]="n_2cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.BKN]="n_3cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.NONE,(int)COVERAGE.OVC]="4cloud_norain.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.FEW]="n_1cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.SCT]="n_2cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.BKN]="n_3cloud_norain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.NONE,(int)COVERAGE.OVC]="4cloud_norain.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.FEW]="n_1cloud_lightrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.SCT]="n_2cloud_lightrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.BKN]="n_3cloud_lightrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.RAIN,(int)COVERAGE.OVC]="4cloud_lightrain.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.FEW]="n_1cloud_modrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.SCT]="n_2cloud_modrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.BKN]="n_3cloud_modrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.RAIN,(int)COVERAGE.OVC]="4cloud_modrain.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.FEW]="n_1cloud_heavyrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.SCT]="n_2cloud_heavyrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.BKN]="n_3cloud_heavyrain.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.RAIN,(int)COVERAGE.OVC]="4cloud_heavyrain.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.FEW]="n_2cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.SCT]="n_2cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.BKN]="n_3cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.SNOW,(int)COVERAGE.OVC]="4cloud_lightsnow.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.FEW]="n_2cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.SCT]="n_2cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.BKN]="n_3cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.SNOW,(int)COVERAGE.OVC]="4cloud_lightsnow.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.FEW]="n_2cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.SCT]="n_2cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.BKN]="n_3cloud_snow.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.SNOW,(int)COVERAGE.OVC]="4cloud_heavysnow.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.FEW]="n_2cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.SCT]="n_2cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.BKN]="n_3cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.HAIL,(int)COVERAGE.OVC]="4cloud_lighthail.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.FEW]="n_2cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.SCT]="n_2cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.BKN]="n_3cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.HAIL,(int)COVERAGE.OVC]="4cloud_lighthail.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.FEW]="n_2cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.SCT]="n_2cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.BKN]="n_3cloud_hail.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.HAIL,(int)COVERAGE.OVC]="4cloud_heavyhail.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.FEW]="n_2cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.SCT]="n_2cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.BKN]="n_3cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.THUN,(int)COVERAGE.OVC]="4cloud_thunders.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.FEW]="n_2cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.SCT]="n_2cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.BKN]="n_3cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.THUN,(int)COVERAGE.OVC]="4cloud_thunders.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.CLR]="n_0cloud.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.FEW]="n_2cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.SCT]="n_2cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.BKN]="n_3cloud_thunders.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.THUN,(int)COVERAGE.OVC]="4cloud_thunders.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.CLR]="n_0cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.FEW]="n_1cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.SCT]="n_2cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.BKN]="n_3cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.LOW,(int)WEATHER.FOG,(int)COVERAGE.OVC]="4cloud_fog.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.CLR]="n_0cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.FEW]="n_1cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.SCT]="n_2cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.BKN]="n_3cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.NORMAL,(int)WEATHER.FOG,(int)COVERAGE.OVC]="4cloud_fog.png";

            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.CLR]="n_0cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.FEW]="n_1cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.SCT]="n_2cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.BKN]="n_3cloud_fog.png";
            images[(int)DAYTIME.NIGHT,(int)INTENSITY.HIGHT,(int)WEATHER.FOG,(int)COVERAGE.OVC]="4cloud_fog.png";


		}

        public string get_sky_image(string str_metar) 
        {
            string metar=str_metar;
            if (str_metar=="")
                return ClassClouds.clouds_nodata_image;
            string[] parts = metar.Split(' ');
            string[] regs=null;
            string[] match=null;
            int num_parts = parts.Length;
            string part;
            this.weather=WEATHER.NONE;
            for (int i = 0; i < num_parts; i++)
            {
                part = parts[i];
                if (ClassEreg.ereg("RMK|TEMPO|BECMG", part))
                {
                    /* The rest of the METAR is either a remark or temporary
                        information. We skip the rest of the METAR. */
                    break;
                }
                else if (ClassEreg.ereg("([0-9]{2})([0-9]{2})([0-9]{2})Z", part,ref regs))
                {
                    if ((System.Convert.ToByte(regs[2]) < 6) || (System.Convert.ToByte(regs[2]) > 18)) 
                    {
                        this.daytime=DAYTIME.NIGHT;
                    }
                }
                else if (ClassEreg.ereg("^(-|\\+|VC)?(TS|SH|FZ|BL|DR|MI|BC|PR|RA|DZ|SN|SG|GR|GS|PE|IC|UP|BR|FG|FU|VA|DU|SA|HZ|PY|PO|SQ|FC|SS|DS)+$", part))
                {
                    /*
                    * Is this the current weather group?
                    */ 

                    // Get the intensity and get rid of it in the part string
                    this.intensity=INTENSITY.NORMAL;     
                    if (ClassEreg.ereg("^(-|\\+|VC)(..)*$", part))
                    {
                        if (part.Substring(1) == "-") 
                        {
                            this.intensity=INTENSITY.LOW;
                            part = part.Substring(1);
                        }
                        else if (part.Substring(1) == "+") 
                        {
                            this.intensity=INTENSITY.HIGHT;
                            part = part.Substring(1);
                        }
                        else if (part.Substring(2) == "VC")
                        {
                            this.intensity=INTENSITY.NORMAL;
                            part = part.Substring(2);
                        }
                    }

                    // Now, take only the precipitation types that have images.
                    // Ignore the others In case more then one exist, take only the
                    // first one (highest predominance).
                    ClassEreg.ereg("(TS|RA|DZ|SN|SG|GR|GS|PE|IC|BR|FG)(..)*$",part,ref match);
                    if (match[1]!="")
                    {
                        phenomena = match[1];
                    }
                    else
                    {
                        ClassEreg.ereg("(..)(TS|RA|DZ|SN|SG|GR|GS|PE|IC|BR|FG)(..)*$", part, ref match);
                        if (match[2]!="") 
                        {
                            phenomena = match[2];
                        }
                        else
                        {
                            this.weather=WEATHER.NONE; // No phenomena.
                        }
                    }
                    switch(phenomena)
                    {
                        case "TS":
                            this.weather=(WEATHER)PHENOMENA.TS;
                            break;
                        case "RA":
                            this.weather=(WEATHER)PHENOMENA.RA;
                            break;
                        case "DZ":
                            this.weather=(WEATHER)PHENOMENA.DZ;
                            break;
                        case "SN":
                            this.weather=(WEATHER)PHENOMENA.SN;
                            break;
                        case "SG":
                            this.weather=(WEATHER)PHENOMENA.SG;
                            break;
                        case "GR":
                            this.weather=(WEATHER)PHENOMENA.GR;
                            break;
                        case "GS":
                            this.weather=(WEATHER)PHENOMENA.GS;
                            break;
                        case "PE":
                            this.weather=(WEATHER)PHENOMENA.PE;
                            break;
                        case "IC":
                            this.weather=(WEATHER)PHENOMENA.IC;
                            break;
                        case "BR":
                            this.weather=(WEATHER)PHENOMENA.BR;
                            break;
                        case "FG":
                            this.weather=(WEATHER)PHENOMENA.FG;
                            break;
                    }
                } 
                if ((this.weather==WEATHER.SNOW)||(this.weather==WEATHER.HAIL))
                {
                    if (this.intensity==INTENSITY.NORMAL)
                    {
                        this.intensity=INTENSITY.LOW;
                    }
                }
                // Add intensity only in case of rain and snow.
                if ((this.weather!=WEATHER.SNOW)&&(this.weather!=WEATHER.HAIL)&&(this.weather!=WEATHER.RAIN))
                {
                    this.intensity=INTENSITY.NORMAL;
                }

                // Now check the cloud coverage. There could be three cloud
                // layers, so check for all of them. Iconize the most covered
                // clouds, thus find the highest cloudcoverage layer, by
                // maximizing the $maxcoverage param
                else if (ClassEreg.ereg("(SKC|CLR)(...)", part,ref regs))
                {
                    this.Condition=regs[1];
                }
                else if (ClassEreg.ereg("^(VV|FEW|SCT|BKN|OVC)([0-9]{3})(CB|TCU)?$", part,ref regs))
                {
                    this.Condition=regs[1];
                }
            }

            int _coverage=0;
            if ((this.coverage==COVERAGE.CAVOK)||(this.coverage==COVERAGE.SKC))
                _coverage=(int)COVERAGE.CLR;
            else if (this.coverage==COVERAGE.VV)
                _coverage=(int)COVERAGE.OVC;
            else
                _coverage=(int)this.coverage;

            // At this point, the $phenomena_group variable contains the one
            // index of the this.images array, while the $maxcoverage
            // variable contains the other index of the this.images array.
            // The correct image can be selected from the array.
            string str_ret=this.images[(int)this.daytime,(int)this.intensity,(int)this.weather,_coverage];
            // allow to have "" better than null for string testing
            if (str_ret==null)
                str_ret="";
            return str_ret;
        }
	}
}
