/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
    public class ClassWindDir
    {
        public const double VRB=-1;
        public double var_beg=0;
        public double var_end=0;
        public double deg=0;
        public ClassWindDir ()
        {

        }
    }
	/// <summary>
	/// Summary description for ClassWind.
	/// </summary>
	public class ClassWind:ClassWeatherInformation
	{
        private const string wind_vrb_image="vrb.png";
        private const string wind_nodir_image="nodir.png";
        private const string wind_nodata_image="wind_nodata.png";
        private string[] wind_dir_images=new string[]{  "NNN.PNG",
                                                        "NNE.PNG",
                                                        "NE.PNG",
                                                        "NEE.PNG",
                                                        "EEE.PNG",
                                                        "SEE.PNG",
                                                        "SE.PNG",
                                                        "SSE.PNG",
                                                        "SSS.PNG",
                                                        "SSW.PNG",
                                                        "SW.PNG",
                                                        "SWW.PNG",
                                                        "WWW.PNG",
                                                        "NWW.PNG",
                                                        "NW.PNG",
                                                        "NNW.PNG",
                                                        "NNN.PNG"
                                                     };

        public ClassWindSpeed speed=null;
        public ClassWindSpeed gust_speed=null;
        public ClassWindDir direction=null;

		public ClassWind()
		{
            this.speed=new ClassWindSpeed();
            this.gust_speed=new ClassWindSpeed();
            this.direction=new ClassWindDir();
		}

        public string get_winddir_image()
        {
            if (this.b_no_data)
                return ClassWind.wind_nodata_image;

            // wind variable
            if (this.direction.deg == ClassWindDir.VRB)
            {
                return ClassWind.wind_vrb_image;
            }
            else if ((this.direction.deg == 0) && (this.speed.Knots == 0))
            {
                return ClassWind.wind_nodir_image;
            } 
            else
            {
                string str_ret=this.wind_dir_images[(int)(System.Math.Round(this.direction.deg/22.5))];
                // allow to have "" better than null for string testing
                if (str_ret==null)
                    str_ret="";
                return str_ret;
            }
        }
	}
}
