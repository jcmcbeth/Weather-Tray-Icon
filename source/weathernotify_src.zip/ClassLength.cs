/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for ClassLength.
	/// </summary>
	public class ClassLength
	{
        public enum UNITS{FEET=0,KM,METER,MILES}
        private double meter  = 0;
        private double km     = 0;
        private double ft     = 0;
        private double miles  = 0;

        public double Meter
        {
            get
            {
                return this.meter;
            }
            set
            {
                this.meter=value;
                this.km=this.meter/1000;
                this.ft=this.meter*3.2808;
                this.miles=this.meter*6.2e-4;
            }
        }
        public double Km
        {
            get
            {
                return this.km;
            }
            set
            {
                this.km=value;
                this.Meter=this.km*1000;
            }
        }
        public double Ft
        {
            get
            {
                return this.ft;
            }
            set
            {
                this.ft=value;
                this.Meter=this.ft/3.2808;
            }
        }
        public double Miles
        {
            get
            {
                return this.miles;
            }
            set
            {
                this.miles=value;
                this.meter=this.miles/6.2e-4;
            }
        }
		public ClassLength()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
