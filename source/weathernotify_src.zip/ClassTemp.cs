/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
    public class ClassTempMinMax:ClassWeatherInformation
    {
        public ClassTemperature min6h=null;
        public ClassTemperature max6h=null;
        public ClassTemperature min24h=null;
        public ClassTemperature max24h=null;
        public ClassTempMinMax()
        {
            this.min6h=new ClassTemperature();
            this.max6h=new ClassTemperature();
            this.min24h=new ClassTemperature();
            this.max24h=new ClassTemperature();
        }
    }
	/// <summary>
	/// Summary description for ClassTemp.
	/// </summary>
	public class ClassTemp:ClassWeatherInformation
	{
        private const string temp_windchilled_image="tempchilled.png";
        private const string temp_high_image="temphigh.png";
        private const string temp_low_image="templow.png";
        private const string temp_nodata_image="temp_nodata.png";


        public ClassTemperature dew=null;
        public ClassTemperature current=null;
        public ClassTempMinMax temp_min_max=null;
        public ClassTemperature windchill=null;
        public ClassTemperature heatindex=null;

		public ClassTemp()
		{
            this.temp_min_max=new ClassTempMinMax();
            this.windchill=new ClassTemperature();
            this.heatindex=new ClassTemperature();
            this.dew=new ClassTemperature();
            this.current=new ClassTemperature();
		}


        /// <summary>
        /// return icon name without path
        /// </summary>
        /// <returns></returns>
        public string get_temp_image() 
        {
            if (this.b_no_data)
                return ClassTemp.temp_nodata_image;

            if (this.windchill.is_set())
            {
                return ClassTemp.temp_windchilled_image;
            }
            else if (this.current.Celcius > 0)
            {
                return ClassTemp.temp_high_image;
            }
            else
            {
                return ClassTemp.temp_low_image;
            }
        }
       
	}
}
