/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
public class Class_StrHash
{
    public string str_hash="";
    public string str_value="";
    public Class_StrHash()
    {
    }
    public Class_StrHash(string str_hash,string str_value)
    {
        this.str_hash=str_hash;
        this.str_value=str_value;
    }
    public static string find_hash_table(string descriptor,Class_StrHash[] array)
    {
        if (array==null)
            return "";
        for (int cnt=0;cnt<array.Length;cnt++)
        {
            if (descriptor==array[cnt].str_hash)
                return array[cnt].str_value;
        }
        // not found
        return "";
    }
}