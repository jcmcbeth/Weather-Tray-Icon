/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
	/// <summary>
	/// 
	/// </summary>
	public class ClassTemperature
	{
        private double celcius=0;
        private double fahrenheit=0;
        private string tenth="0000";
        public enum UNITS{FAHRENHEIT=0,CELCIUS};
        public double Celcius
        {
            get
            {
                return this.celcius;
            }
            set
            {
                this.celcius=value;
                /* The temperature in Fahrenheit. */
                this.fahrenheit = this.celcius * (9.0/5) + 32;
                string s;
                s=System.Math.Round(this.celcius*10).ToString();
                if (s.Length<3)
                    s="0"+s;
                else if (s.Length>=3)
                    s=s.Substring(0,3);
                if (this.celcius<0)
                    s="1"+s;
                else
                    s="0"+s;
                this.tenth=s;
            }
        }
        public double Fahrenheit
        {
            get
            {
                return this.fahrenheit;
            }
            set
            {
                this.fahrenheit=value;
                this.Celcius = (this.fahrenheit- 32) * (5.0/9) ;
            }
        }
        public string Tenth
        {
            get
            {
                return this.tenth;
            }
            set
            {
                this.tenth=value; 
                double d;
                /*
                * Note: temp is converted to negative if temp > 100.0 (See
                * Federal Meteorological Handbook for groups T, 1, 2 and 4). 
                * For example, a temperature of 2.6�C and dew point of -1.5�C 
                * would be reported in the body of the report as "03/M01" and the
                * TsnT'T'T'snT'dT'dT'd group as "T00261015").  
                */
                if (this.tenth.StartsWith("1")) 
                {
                    d = -System.Convert.ToDouble(this.tenth.Substring(1));
                }
                else
                    d=System.Convert.ToDouble(this.tenth);
                this.celcius=d;
                /* The temperature in Fahrenheit. */
                this.fahrenheit = d * (9.0/5) + 32;
            }
        }
		public ClassTemperature()
		{
			// 
			// TODO: Add constructor logic here
			//
		}
        public bool is_set()
        {
            return (!(this.celcius==this.fahrenheit));// this.celcius==this.fahrenheit only possible if not set (the two are nuls)
        }

        public string get_string(UNITS unit,bool space)
        {
            string str="";
            switch (unit)
            {
                case UNITS.CELCIUS:
                    str=this.Celcius.ToString("0");
                    if (space)
                        str+=" ";
                        str+="�C";
                    break;
                case UNITS.FAHRENHEIT:
                    str=this.Fahrenheit.ToString("0");
                    if (space)
                        str+=" ";
                    str+="�F";
                    break;
            }
            return str;
        }

        public string get_string(UNITS unit)
        {
            return this.get_string(unit,true);
        }
	}
}
