/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
    public class ClassWindSpeed
    {
        public enum UNITS {MS=0,KMH,MH,KNOTS,BEAUFORT};
        private int beaufort=0;
        private double ms=0;
        private double knots=0;
        private double mileshours=0;
        private double kmh=0;
        public int Beaufort
        {
            get
            {
                return this.beaufort;
            }
            set
            {
                this.beaufort=value;
                this.Ms=this.beaufort_array[this.beaufort];// let the work being done by Ms setter
            }
        }
        public double Knots
        {
            get
            {
                return this.knots;
            }
            set
            {
                this.knots=value;
                this.Ms=this.knots*0.5144;
            }
        }
        public double Ms
        {
            get
            {
                return this.ms;
            }
            set
            {
                this.ms=value;
                this.beaufort=this.get_beaufort();
                this.kmh=this.ms*3.6;
                this.knots=this.ms/0.5114;
                this.mileshours=this.knots*1.1508;
            }
        }
        public double Kmh
        {
            get
            {
                return this.kmh;
            }
            set
            {
                this.kmh=value;
                this.Ms=this.kmh/3.6;
            }
        }
        public double Mileshours
        {
            get
            {
                return this.mileshours;
            }
            set
            {
                this.mileshours=value;
                this.Ms=this.mileshours/1.1508;
            }
        }

        private double[] beaufort_array=new double[13]
                                {// beaufort=index
                                    0.3, // beaufort=0
                                    1.6, // beaufort=1
                                    3.4, // beaufort=2
                                    5.5, // beaufort=3
                                    8.0, // beaufort=4
                                    10.8, // beaufort=5
                                    13.9, // beaufort=6
                                    17.2, // beaufort=7
                                    20.8, // beaufort=8
                                    24.5, // beaufort=9
                                    28.5, // beaufort=10
                                    32.7, // beaufort=11
                                    999 // beaufort=12
                                };

        private byte get_beaufort()
        {
            byte cnt = 0;
            while ((this.ms > beaufort_array[cnt]) && (cnt <= 12))
            {
                cnt++;
            }
            return cnt;
        }

        /// <summary>
        /// Set speed
        /// </summary>
        /// <param name="wind_value"></param>
        /// <param name="windunit">allowed units "KT","MPS","KMH","MIH" </param>
        public void set_speed(double wind_value, string windunit)
        {
            switch(windunit)
            {
                case "KT":
                    /* The windspeed measured in knots: */
                    this.Knots=wind_value;
                    break;
                case "MPS":
                    /* The windspeed measured in meters per second */
                    this.Ms=wind_value;
                    break;
                case "KMH":
                    /* The windspeed measured in kilometers per hour */
                    this.Kmh=wind_value;
                    break;
                case "MIH":
                    this.Mileshours=wind_value;
                    break;
            }
        }
    }
}