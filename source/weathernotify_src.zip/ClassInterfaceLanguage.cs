/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for ClassInterfaceLanguage.
	/// </summary>
	public class ClassInterfaceLanguage
	{
        public string options="Options";
        public string show_hide="Show/Hide";
        public string about="About";
        public string details="Details";
        public string country_city="Country : City";
        public string current_state="Current State";
        public string started="Started";
        public string stopped="Stopped";
        public string notify_icons="Notify Icons";
        public string clouds="Clouds";
        public string temperature="Temperature";
        public string weather="Weather";
        public string wind="Wind";
        public string wind_speed="Wind Speed";
        public string wind_direction="Wind Direction";
        public string pressure="Pressure";
        public string top_most_window="Top Most Window";
        public string window_opacity="Window Opacity";
        public string window="Window";
        public string orientation="Orientation";
        public string length="Length";
        public string height="Height";
        public string precipitation_height="Precipitation Height";
        public string language="Language";
        public string apply="Apply";
        public string cancel="Cancel";
        public string exit="Exit";
        public string units="Units";
        public string city="City";


		public ClassInterfaceLanguage()
		{

		}

        public static ClassInterfaceLanguage load(string config_file_name)
        {
            try
            {
                if (System.IO.Path.GetFileNameWithoutExtension(config_file_name)=="")// don't show error if application is run for first time 
                    return new ClassInterfaceLanguage();
                return (ClassInterfaceLanguage)XML_access.XMLDeserializeObject(config_file_name,typeof(ClassInterfaceLanguage));
            }
            catch(Exception e)
            {
                System.Windows.Forms.MessageBox.Show("Error loading interface language file "+config_file_name+".\r\n"+e.Message+"\r\nDefault language will be used for interface","Error",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
                return new ClassInterfaceLanguage();
            }
        }
        public bool save(string config_file_name)
        {
            try
            {
                XML_access.XMLSerializeObject(config_file_name,this,typeof(ClassInterfaceLanguage));
                return true;
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message,"Error",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
                return false;            
            }
        }

	}
}
