/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for FormAbout.
	/// </summary>
	public class FormAbout : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Label label_app_name;
        private System.Windows.Forms.Button button_OK;
        private System.Windows.Forms.Label label_app_description;
        private System.Windows.Forms.Label label_app_version;
        private System.Windows.Forms.Label label_website;
        private System.Windows.Forms.LinkLabel linkLabel_website;
        private System.Windows.Forms.Label label_phpweather;
        private System.Windows.Forms.LinkLabel linkLabel_phpweather;
        private System.Windows.Forms.PictureBox pictureBox_phpweather;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FormAbout()
		{
			InitializeComponent();
            this.label_app_version.Text="Version :"+System.Windows.Forms.Application.ProductVersion;
            XPStyle.MakeXPStyle(this);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormAbout));
            this.label_app_name = new System.Windows.Forms.Label();
            this.button_OK = new System.Windows.Forms.Button();
            this.label_app_description = new System.Windows.Forms.Label();
            this.label_app_version = new System.Windows.Forms.Label();
            this.label_website = new System.Windows.Forms.Label();
            this.linkLabel_website = new System.Windows.Forms.LinkLabel();
            this.label_phpweather = new System.Windows.Forms.Label();
            this.linkLabel_phpweather = new System.Windows.Forms.LinkLabel();
            this.pictureBox_phpweather = new System.Windows.Forms.PictureBox();
            this.SuspendLayout();
            // 
            // label_app_name
            // 
            this.label_app_name.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.label_app_name.Location = new System.Drawing.Point(57, 0);
            this.label_app_name.Name = "label_app_name";
            this.label_app_name.Size = new System.Drawing.Size(184, 32);
            this.label_app_name.TabIndex = 0;
            this.label_app_name.Text = "Weather Notify";
            this.label_app_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_OK
            // 
            this.button_OK.Location = new System.Drawing.Point(112, 208);
            this.button_OK.Name = "button_OK";
            this.button_OK.TabIndex = 1;
            this.button_OK.Text = "Ok";
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // label_app_description
            // 
            this.label_app_description.Location = new System.Drawing.Point(0, 56);
            this.label_app_description.Name = "label_app_description";
            this.label_app_description.Size = new System.Drawing.Size(296, 32);
            this.label_app_description.TabIndex = 2;
            this.label_app_description.Text = "This application is a open source freeware under GPL License. It\'s a C# translati" +
                "on of phpweather 2.2.2";
            this.label_app_description.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_app_version
            // 
            this.label_app_version.Location = new System.Drawing.Point(96, 32);
            this.label_app_version.Name = "label_app_version";
            this.label_app_version.Size = new System.Drawing.Size(200, 16);
            this.label_app_version.TabIndex = 3;
            this.label_app_version.Text = "Version";
            // 
            // label_website
            // 
            this.label_website.Location = new System.Drawing.Point(17, 104);
            this.label_website.Name = "label_website";
            this.label_website.Size = new System.Drawing.Size(208, 16);
            this.label_website.TabIndex = 4;
            this.label_website.Text = "Binaries and sources can be found at:";
            // 
            // linkLabel_website
            // 
            this.linkLabel_website.Location = new System.Drawing.Point(129, 120);
            this.linkLabel_website.Name = "linkLabel_website";
            this.linkLabel_website.Size = new System.Drawing.Size(152, 16);
            this.linkLabel_website.TabIndex = 5;
            this.linkLabel_website.TabStop = true;
            this.linkLabel_website.Text = "http://jacquelin.potier.free.fr/";
            this.linkLabel_website.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_website_LinkClicked);
            // 
            // label_phpweather
            // 
            this.label_phpweather.Location = new System.Drawing.Point(121, 160);
            this.label_phpweather.Name = "label_phpweather";
            this.label_phpweather.Size = new System.Drawing.Size(160, 16);
            this.label_phpweather.TabIndex = 6;
            this.label_phpweather.Text = "PHPWeather can be found at :";
            // 
            // linkLabel_phpweather
            // 
            this.linkLabel_phpweather.Location = new System.Drawing.Point(129, 176);
            this.linkLabel_phpweather.Name = "linkLabel_phpweather";
            this.linkLabel_phpweather.Size = new System.Drawing.Size(152, 16);
            this.linkLabel_phpweather.TabIndex = 7;
            this.linkLabel_phpweather.TabStop = true;
            this.linkLabel_phpweather.Text = "http://www.phpweather.net/";
            this.linkLabel_phpweather.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_phpweather_LinkClicked);
            // 
            // pictureBox_phpweather
            // 
            this.pictureBox_phpweather.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_phpweather.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_phpweather.Image")));
            this.pictureBox_phpweather.Location = new System.Drawing.Point(17, 144);
            this.pictureBox_phpweather.Name = "pictureBox_phpweather";
            this.pictureBox_phpweather.Size = new System.Drawing.Size(104, 64);
            this.pictureBox_phpweather.TabIndex = 8;
            this.pictureBox_phpweather.TabStop = false;
            this.pictureBox_phpweather.Click += new System.EventHandler(this.pictureBox_phpweather_Click);
            // 
            // FormAbout
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(298, 240);
            this.Controls.Add(this.pictureBox_phpweather);
            this.Controls.Add(this.linkLabel_phpweather);
            this.Controls.Add(this.label_phpweather);
            this.Controls.Add(this.linkLabel_website);
            this.Controls.Add(this.label_website);
            this.Controls.Add(this.label_app_version);
            this.Controls.Add(this.label_app_description);
            this.Controls.Add(this.button_OK);
            this.Controls.Add(this.label_app_name);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAbout";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About";
            this.TopMost = true;
            this.ResumeLayout(false);

        }
		#endregion

        private void button_OK_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void linkLabel_website_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
        {
                this.VisitLink(linkLabel_website.Text);
                // Change the color of the link text by setting LinkVisited 
                // to true.
                this.linkLabel_website.LinkVisited = true;
        }

        private void VisitLink(string url)
        {
            try
            {
                //Call the Process.Start method to open the default browser 
                //with a URL:
                System.Diagnostics.Process.Start(url);
            }
            catch (Exception e)
            {
                MessageBox.Show(this,e.Message,"Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void linkLabel_phpweather_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
        {
            this.VisitLink(linkLabel_phpweather.Text);
            // Change the color of the link text by setting LinkVisited 
            // to true.
            this.linkLabel_phpweather.LinkVisited = true;        
        }

        private void pictureBox_phpweather_Click(object sender, System.EventArgs e)
        {
            this.linkLabel_phpweather_LinkClicked(sender,null);
        }
	}
}
