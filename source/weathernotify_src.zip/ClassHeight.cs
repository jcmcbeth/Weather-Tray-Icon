/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
	/// <summary>
	/// Summary description for ClassHeight.
	/// </summary>
	public class ClassHeight
	{
        public enum UNITS{INCH=0,MM}
        private double inch=0;
        private double mm=0;

        public double Inch
        {
            get
            {
                return this.inch;
            }
            set
            {
                this.inch=value;
                this.mm=this.inch*0.254;
            }
        }

        public double Mm
        {
            get
            {
                return this.mm;
            }
            set
            {
                this.mm=value;
                this.inch=this.mm/0.254;
            }
        }

		public ClassHeight()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
