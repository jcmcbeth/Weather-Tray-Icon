/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
using System;

namespace WeatherNotify
{
    #region events /eventargs
    /// <summary>
    /// used to raise Exception
    /// contains exception
    /// </summary>
    public class EventArgs_Exception:EventArgs
    {
        public readonly Exception exception;
        public EventArgs_Exception(Exception e)
        {
            exception=e;
        }
    }

    /// <summary>
    /// used to raise data
    /// contains string data
    /// </summary>
    public class EventArgs_StringData:EventArgs
    {
        public readonly string data="";
        public EventArgs_StringData(string data)
        {
            this.data=data;
        }
    }

    public delegate void MetarDownload_Error_EventHandler(ClassMetarDownload sender, EventArgs_Exception e);
    public delegate void MetarDownload_Arrival_EventHandler(ClassMetarDownload sender, EventArgs_StringData e);
    #endregion

    public class ClassMetarDownload
    {
        public event MetarDownload_Error_EventHandler event_MetarDownload_Error;
        public event MetarDownload_Arrival_EventHandler event_MetarDownload_Arrival;
        public string host="weather.noaa.gov";//"127.0.0.1";//"weather.noaa.gov";//
        public string location="/pub/data/observations/metar/stations/";
        private UInt32 retry_sec=300;// 5min
        private bool b_stopped=true;
        public bool Started
        {
            get{return !this.b_stopped;}
        }
        private System.DateTime last_update;
        private int thread_delay_in_sec=0;
        private System.Threading.AutoResetEvent hevt_thread_start;
        private System.Threading.ManualResetEvent hevt_stop_event;
        private System.Threading.ManualResetEvent hevt_socket_closed;
        private string icao="";
        private System.Timers.Timer timer_update;
        private easy_socket.tcp.Socket_Data socket;
        private string request="";
        private string rcv_buff="";

        public ClassMetarDownload()
        {
            this.hevt_thread_start=new System.Threading.AutoResetEvent(false);
            this.hevt_stop_event=new System.Threading.ManualResetEvent(false);
            this.hevt_socket_closed=new System.Threading.ManualResetEvent(false);
            this.timer_update=new System.Timers.Timer();
            this.timer_update.Enabled=false;
            this.timer_update.Elapsed+=new System.Timers.ElapsedEventHandler(timer_update_Elapsed);
            this.socket=new easy_socket.tcp.Socket_Data();
            this.socket.event_Socket_Data_Closed_by_Remote_Side+=new easy_socket.tcp.Socket_Data_Closed_by_Remote_Side_EventHandler(socket_event_Socket_Data_Closed_by_Remote_Side);
            this.socket.event_Socket_Data_Connected_To_Remote_Host+=new easy_socket.tcp.Socket_Data_Connected_To_Remote_Host_EventHandler(socket_event_Socket_Data_Connected_To_Remote_Host);
            this.socket.event_Socket_Data_DataArrival+=new easy_socket.tcp.Socket_Data_DataArrival_EventHandler(socket_event_Socket_Data_DataArrival);
            this.socket.event_Socket_Data_Error+=new easy_socket.tcp.Socket_Data_Error_EventHandler(socket_event_Socket_Data_Error);
        }

        #region start/stop
        public void start(string icao,UInt32 update_interval_in_sec,UInt32 retry_in_sec,string host,string remote_path_folder)
        {
            this.retry_sec=retry_in_sec;
            this.location=remote_path_folder;
            this.host=host;
            this.stop();
            // assume that event has been thrown
            this.hevt_stop_event.WaitOne(1000,true);
            // let time to old threads to stop
            System.Threading.Thread.Sleep(200);
            this.icao=icao;
            this.timer_update.Interval=update_interval_in_sec*1000;
            this.hevt_stop_event.Reset();
            this.b_stopped=false;
            // create thread for mystart
            System.Threading.ThreadStart ths=new System.Threading.ThreadStart(mystart);
            System.Threading.Thread th=new System.Threading.Thread(ths);
            th.Start();
        }
        private void mystart()
        {
            // check get metar for first time
            this.start_download_delay(0,false);
            this.timer_update.Enabled=true;
        }
        
        public void stop()
        {
            // stop timer
            this.timer_update.Enabled=false;
            this.b_stopped=true;
            // set the hevt_stop_event
            this.hevt_stop_event.Set();
        }
        private void start_download_delay(UInt32 delay_in_sec,bool b_blocking)
        {
            if (this.b_download_already_delay)// a download is already delay
                return;
            this.b_download_already_delay=true;
            this.thread_delay_in_sec=(int)delay_in_sec;
            if (b_blocking)
            {
                this.start_download_delay();
            }
            else
            {
                System.Threading.ThreadStart ths=new System.Threading.ThreadStart(start_download_delay);
                System.Threading.Thread th=new System.Threading.Thread(ths);
                th.Start();
                this.hevt_thread_start.Reset();
                this.hevt_thread_start.WaitOne(3000,true);
            }
        }
        private bool b_download_already_delay=false;

        private void start_download_delay()
        {
            int delay_in_sec=this.thread_delay_in_sec;
            // data are saved continue
            this.hevt_thread_start.Set();

            if(this.hevt_stop_event.WaitOne(delay_in_sec*1000,true))// stop event occurs
            {
                this.b_download_already_delay=false;
                return;
            }
            // else

            // download
            bool b_success=this.get_metar_from_web();
            // a new download can be delay
            this.b_download_already_delay=false;
            // if error during download
            if ((!b_success)&&(!this.b_stopped))
                // start another delay download
                this.start_download_delay(this.retry_sec,false);
        }

        #endregion

        #region download
        /// <summary>
        /// The METAR is fetched via HTTP from the National Weather Services
        /// public server. The files can be found under the
        /// http://weather.noaa.gov/pub/data/observations/metar/stations/
        /// directory as ICAO.TXT where ICAO is replaced by the actual ICAO.
        /// </summary>
        /// <param name="icao"></param>
        /// <returns>success status</returns>
        public bool get_metar_from_web()
        {
            string metar_data;
            string metar = "";
            string str_date;
            string[] pdate;
            metar_data = this.get_metar_socket(this.icao);
            /* Here we test to see if we actually got a METAR. */
            if (metar_data!="")
            {
                int pos_end_of_header=metar_data.IndexOf("\r\n\r\n");
                int pos_200_ok=metar_data.IndexOf(" 200 ");
                if ((pos_200_ok<0)||(pos_end_of_header<0)||(pos_end_of_header<pos_200_ok))
                {
                    int pos_404_not_found=metar_data.IndexOf(" 404 ");
                    if ((pos_404_not_found>0)&&(pos_end_of_header>0)&&(pos_end_of_header>pos_404_not_found))
                    {
                        // pretty error message
                        // throw error
                        if (this.event_MetarDownload_Error!=null)
                            this.event_MetarDownload_Error(this,new EventArgs_Exception(new Exception("City informations not found on server "+this.host+" !")));
                    }
                    else // let message
                    {
                        // throw error
                        if (this.event_MetarDownload_Error!=null)
                            this.event_MetarDownload_Error(this,new EventArgs_Exception(new Exception("Bad data:\r\n"+metar_data)));
                    }
                    return false;
                }
                metar_data=metar_data.Substring(pos_end_of_header+4);
                /* The first line in the file is the date */
                int eol=metar_data.IndexOfAny(new char[]{'\r','\n'});
                if (eol<0)
                {
                    // throw error
                    if (this.event_MetarDownload_Error!=null)
                        this.event_MetarDownload_Error(this,new EventArgs_Exception(new Exception("Bad data:\r\n"+metar_data)));
                    return false;
                }
                str_date = metar_data.Substring(0,eol).Trim();
                // remove date from metar
                metar_data = metar_data.Substring(eol+1);
                /* The remaining lines are the METAR itself. This will merge the
                * remaining lines into one line by removing new-lines:
                */
                // ereg_replace("[\n\r ]+", " ", );
                metar = metar_data.Replace("\n"," ").Replace("\r","");
                // first line contains date and is like is like 2004/11/28 10:00
                pdate = str_date.Split(new char[]{':','/',' '});
                // pdate is like is like [yyyy,mm,dd,hh,mm]
                if (pdate.Length>=5)
                {
                    this.last_update=new System.DateTime(System.Convert.ToInt32(pdate[0]),
                                                        System.Convert.ToInt32(pdate[1]),
                                                        System.Convert.ToInt32(pdate[2]),
                                                        System.Convert.ToInt32(pdate[3]),
                                                        System.Convert.ToInt32(pdate[4]),
                                                        0);
                }
                if (!ClassEreg.ereg("[0-9]{6}Z", metar))
                {
                    /* Some reports don't even have a time-part, so we insert the
                    * current time. This might not be the time of the report, but
                    * it was broken anyway :-)
                    */
                    this.last_update=System.DateTime.Now;
                }
                // throw event metar arrival (metar)
                if (this.event_MetarDownload_Arrival!=null)
                    this.event_MetarDownload_Arrival(this,new EventArgs_StringData(metar));
                return true;
            }
            /*
            else
            {
                // error retreiving metar
                // no action yet
            }
            */
            return false;
        }

        public string get_metar_socket(string icao)
        {
            string strlocation = this.location+icao+".TXT";
            this.request = "HTTP/1.1\r\n";
            //                            +"If-Modified-Since: Sat, 29 Oct 1994 09:00:00 GMT\r\n"
            //                            +"Pragma: no-cache\r\n"
            //                            +"Cache-Control: no-cache\r\n";
              
            this.request = "GET "+strlocation+" "+request
                        +"Host: "+this.host+"\r\n"
                        +"Content-Type: text/html\r\n"
                        +"Connection: Close\r\n\r\n";

            string metar_data="";
            this.hevt_socket_closed.Reset();
            this.socket.connect(this.host,80); 
            // wait for multiple object event stop /connnection closed,error,(cancel not implemented,timeout included with socket timeout)
            System.Threading.WaitHandle.WaitAny(new System.Threading.WaitHandle[]{this.hevt_stop_event,this.hevt_socket_closed});
            metar_data=this.rcv_buff;
            this.socket.close();// close if not already done
            
            return metar_data;
        }

        private void socket_event_Socket_Data_Closed_by_Remote_Side(easy_socket.tcp.Socket_Data sender, EventArgs e)
        {
            // event
            this.hevt_socket_closed.Set();
        }

        private void socket_event_Socket_Data_Connected_To_Remote_Host(easy_socket.tcp.Socket_Data sender, EventArgs e)
        {
            this.rcv_buff="";
            this.socket.send(this.request);
        }

        private void socket_event_Socket_Data_DataArrival(easy_socket.tcp.Socket_Data sender, easy_socket.tcp.EventArgs_ReceiveDataSocket e)
        {
            this.rcv_buff+=System.Text.Encoding.Default.GetString(e.buffer , 0, e.buffer_size );
        }

        private void socket_event_Socket_Data_Error(easy_socket.tcp.Socket_Data sender, easy_socket.tcp.EventArgs_Exception e)
        {
            // throw error
            if (this.event_MetarDownload_Error!=null)
                this.event_MetarDownload_Error(this,new EventArgs_Exception(e.exception));
            // event
            this.hevt_socket_closed.Set();
        }
        #endregion

        private void timer_update_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.start_download_delay(0,false);
        }
    }
}
