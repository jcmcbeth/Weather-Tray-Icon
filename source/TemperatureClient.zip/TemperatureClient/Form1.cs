using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text.RegularExpressions;

namespace TemperatureClient
{
	/// <summary>
	/// This is the main form in the program.  It gets the user's input, calls the web service to get the
	/// current temperature for the given zipcode, and then displays the result.  The main action is in
	/// the button1_Click handler.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox zipCodeEntry;
		private System.Windows.Forms.Button btnOK;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private Regex validator = new Regex( "^[0-9]{5}$" );

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.zipCodeEntry = new System.Windows.Forms.TextBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(38, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(144, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Please enter a zip code:";
			// 
			// zipCodeEntry
			// 
			this.zipCodeEntry.Location = new System.Drawing.Point(192, 8);
			this.zipCodeEntry.MaxLength = 5;
			this.zipCodeEntry.Name = "zipCodeEntry";
			this.zipCodeEntry.Size = new System.Drawing.Size(64, 20);
			this.zipCodeEntry.TabIndex = 1;
			this.zipCodeEntry.Text = "95014";
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(208, 48);
			this.btnOK.Name = "btnOK";
			this.btnOK.TabIndex = 2;
			this.btnOK.Text = "OK";
			this.btnOK.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 78);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnOK,
																		  this.zipCodeEntry,
																		  this.label1});
			this.Name = "Form1";
			this.Text = "Get Temperature by Zip Code";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			// Check that the user entered a valid zip code (i.e., all digits, no characters)
			if ( zipCodeEntry.Text == "" || ( !validator.IsMatch( zipCodeEntry.Text ) ) )
			{
				MessageBox.Show( "You must enter a valid zipcode." );
				return;
			}

			// We're going to use this to convert Fahrenheit to Celsius.
			Single tempCelsius;

			// TemperatureService is the proxy to the web service.  First, instantiate the proxy:
			TemperatureService tempSvc = new TemperatureService( );

			// Next, call the service via the proxy:
			Single result = tempSvc.getTemp( zipCodeEntry.Text );

			// Convert Fahrenheit to Celsius:
			tempCelsius = ( ( result - 32 ) * (float)0.555555556 );

			// 0x00B0 is the degree sign in Unicode.
			// Show the user the current temperature for the entered zipcode in Fahrenheit and Celsius:
			MessageBox.Show( "Current temperature in " + zipCodeEntry.Text + " is:\n\n" + 
				((int)result).ToString( ) + (char)0x00B0 + " Fahrenheit\n" + ((int)tempCelsius).ToString( ) +
				(char)0x00B0 + " Celsius" );
		}
	}
}
