NO WARRANTY:
This source code is provided "As-Is", and no warranty is either expressed or implied.
Neither Jeff Galyan nor Anamorphic Software, Inc., shall be liable for any damage, real 
or imagined, incurred through the use, download, or any other situation you can imagine,
of this source code.

That being stated, here's the important bits:

wsdl.exe was used to generate the TemperatureService.cs source file.  Don't make any
changes to that file manually, or you'll lose them if you run wsdl.exe again.

Form1.cs is the "form" file (really, the main source code file, but this is what
VS .NET names it when you create the project).  This file is where the action is.
Look at the "button1_Click" handler.  

Yes, there are improvements that can be made, but it was 3:00 AM when I wrote it, so 
bear with me there.  At least I did get the Fahrenheit to Celsius conversion in there.
The better way to validate the input field to ensure all digits would be to derive from 
text field class and override whatever method is called for each key press.

If you're interested, take a look at the "References" section of the project properties.
You'll see listed there some essential dll linkages for web service clients.

